"""Run the whole pipeline:  collect -> normalize/dedupe -> ATT&CK map -> enrich -> score -> STIX.

    python pipeline.py            # real feeds (needs keys in .env)
    python pipeline.py --demo     # fake data, no keys needed
"""
import argparse
import sys
from db import init_db, connect, upsert_ioc
from attack_map import Attack, map_all
from enrich import enrich_ips, score_confidence
from stix_export import export_bundle
from collectors import otx, threatfox, urlhaus, malwarebazaar


def collect_live(days):
    items = []
    for name, fn in [("otx", lambda: otx.collect(days=max(days, 1))),
                     ("threatfox", lambda: threatfox.collect(days=min(days, 7))),
                     ("urlhaus", urlhaus.collect),
                     ("malwarebazaar", malwarebazaar.collect)]:
        try:
            items += fn()
        except Exception as e:  # one broken feed should not stop the others
            print(f"[{name}] FAILED: {e}")
    return items


def summary(conn):
    stats = [
        ("Unique IOCs stored", "SELECT COUNT(*) FROM iocs"),
        ("IOCs first seen in last 24h", "SELECT COUNT(*) FROM iocs WHERE first_seen >= datetime('now','-1 day')"),
        ("Seen by 2+ feeds (deduped)", "SELECT COUNT(*) FROM iocs WHERE sources LIKE '%,%'"),
        ("Malware families", "SELECT COUNT(DISTINCT malware_family) FROM iocs"),
        ("IOCs mapped to ATT&CK", "SELECT COUNT(DISTINCT ioc_id) FROM ioc_techniques"),
        ("ATT&CK techniques covered", "SELECT COUNT(DISTINCT technique_id) FROM ioc_techniques"),
        ("ATT&CK tactics covered (of 14)", "SELECT COUNT(DISTINCT tactic) FROM ioc_techniques WHERE tactic != 'unknown'"),
        ("IPs enriched", "SELECT COUNT(*) FROM iocs WHERE enriched = 1"),
    ]
    print("\n===== Numbers for your resume / README =====")
    for label, sql in stats:
        print(f"{label:<32}: {conn.execute(sql).fetchone()[0]:,}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true", help="use fake demo data (no API keys)")
    ap.add_argument("--days", type=int, default=1, help="how many days back to pull")
    ap.add_argument("--skip-enrich", action="store_true")
    ap.add_argument("--stix-days", type=int, default=7)
    ap.add_argument("--min-confidence", type=int, default=50)
    args = ap.parse_args()

    init_db()
    if args.demo:
        import demo_data
        items = demo_data.generate()
        print(f"[demo] generated {len(items)} fake indicators")
    else:
        items = collect_live(args.days)
        if not items:
            sys.exit("No indicators collected. Check your .env keys, or try: python pipeline.py --demo")

    with connect() as conn:
        for it in items:
            upsert_ioc(conn, it)
        print(f"[db] processed {len(items)} raw indicators")
        map_all(conn, Attack())
        if args.demo:
            demo_data.fake_enrich(conn, items)
        elif not args.skip_enrich:
            enrich_ips(conn)
        score_confidence(conn)
        export_bundle(conn, days=args.stix_days, min_confidence=args.min_confidence)
        summary(conn)
    print("\nDone. Start the dashboard with:  streamlit run dashboard.py")


if __name__ == "__main__":
    main()
