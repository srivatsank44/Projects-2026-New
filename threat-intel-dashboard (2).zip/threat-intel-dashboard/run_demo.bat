@echo off
python -m pip install -r requirements.txt
python pipeline.py --demo
streamlit run dashboard.py
