"""Fake but realistic data so you can see the dashboard before you have API keys.
Uses reserved documentation IP ranges and .example domains, so nothing here is a real IOC."""
import random
from datetime import datetime, timedelta, timezone

FAMILIES = {  # family -> (weight, typical threat type)
    "Agent Tesla": (14, "payload_delivery"), "Cobalt Strike": (12, "botnet_cc"),
    "QakBot": (9, "botnet_cc"), "Emotet": (8, "payload_delivery"), "AsyncRAT": (10, "botnet_cc"),
    "Remcos": (9, "botnet_cc"), "njRAT": (6, "botnet_cc"), "IcedID": (5, "payload_delivery"),
    "Lumma Stealer": (11, "payload_delivery"), "Mozi": (7, "payload_delivery"),
    "Formbook": (6, "payload_delivery"), None: (8, None),
}
COUNTRIES = ["US", "NL", "DE", "RU", "CN", "FR", "SG", "HK", "BR", "UA", "GB", "BG"]
NETS = ["192.0.2.", "198.51.100.", "203.0.113."]


def generate(n=1500, days=14, seed=7):
    rnd = random.Random(seed)
    now = datetime.now(timezone.utc)
    fams, weights = zip(*[(f, w) for f, (w, _) in FAMILIES.items()])
    out = []
    for i in range(n):
        fam = rnd.choices(fams, weights)[0]
        src = rnd.choices(["threatfox", "urlhaus", "malwarebazaar", "otx"], [35, 25, 20, 20])[0]
        t = {"urlhaus": "url", "malwarebazaar": "sha256"}.get(
            src, rnd.choice(["ipv4", "ipv4", "domain", "url", "sha256"]))
        slug = (fam or "unknown").lower().replace(" ", "")
        value = {
            "ipv4": rnd.choice(NETS) + str(rnd.randint(1, 254)),
            "domain": f"{slug}-{rnd.randint(100, 9999)}.example",
            "url": f"http://{slug}-{rnd.randint(100, 999)}.example/{rnd.choice(['load','gate','bin','x'])}.php",
            "sha256": "%064x" % rnd.getrandbits(256),
        }[t]
        age = rnd.betavariate(1.2, 2.5) * days  # more recent activity than old
        out.append({
            "value": value, "type": t,
            "first_seen": (now - timedelta(days=age)).strftime("%Y-%m-%d %H:%M:%S"),
            "malware_family": fam, "threat_type": FAMILIES[fam][1],
            "tags": "demo", "source": src, "source_conf": rnd.choice([50, 75, 75, 90, 100]),
            "_country": rnd.choice(COUNTRIES), "_abuse": rnd.randint(0, 100),
        })
    return out


def fake_enrich(conn, items):
    for it in items:
        if it["type"] == "ipv4":
            conn.execute("""UPDATE iocs SET country=?, asn=?, abuse_score=?, enriched=1
                            WHERE value=? AND type='ipv4'""",
                         (it["_country"], f"AS{64496 + int(it['value'].split('.')[-1]) % 15} Demo Net",
                          it["_abuse"], it["value"]))
