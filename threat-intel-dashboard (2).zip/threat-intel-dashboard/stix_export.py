"""Export IOCs as a STIX 2.1 bundle: Indicators, Malware families, ATT&CK Attack-Patterns,
and the Relationships between them. IDs are deterministic, so re-runs update, not duplicate.
Any indicator that fails validation or serialization is skipped and reported, never fatal."""
import json
import uuid
from datetime import datetime, timedelta, timezone
from stix2 import Identity, Indicator, Malware, AttackPattern, Relationship
from config import OUTPUT_DIR

NS = uuid.UUID("6f6c2a8e-1d9b-4c6e-9f2a-7c1e3b5d8a40")
PATTERNS = {
    "ipv4": "[ipv4-addr:value = '{}']",
    "domain": "[domain-name:value = '{}']",
    "url": "[url:value = '{}']",
    "sha256": "[file:hashes.'SHA-256' = '{}']",
    "md5": "[file:hashes.MD5 = '{}']",
}


def _id(kind, key):
    return f"{kind}--{uuid.uuid5(NS, f'{kind}:{key}')}"


def _ts(s):
    try:
        return datetime.strptime(str(s)[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except ValueError:
        return datetime.now(timezone.utc)


def _to_dict(obj):
    """Serialize one STIX object to a plain dict (raises if it can't be serialized)."""
    return json.loads(obj.serialize())


def _clean(s):
    """Strip characters that break STIX patterns (control chars, newlines)."""
    return "".join(ch for ch in str(s) if ch.isprintable()).strip()


def export_bundle(conn, days=7, min_confidence=50):
    since = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    rows = conn.execute("""SELECT * FROM iocs WHERE first_seen >= ? AND confidence >= ?
                           ORDER BY first_seen DESC""", (since, min_confidence)).fetchall()
    total = len(rows)
    print(f"[stix] building bundle for {total:,} indicators (this can take a few minutes)...")

    me = Identity(id=_id("identity", "producer"), name="Open-Source Threat Intel Pipeline",
                  identity_class="system")
    out, malware, patterns, rels = [_to_dict(me)], {}, {}, set()
    skipped, first_error = 0, None

    for i, r in enumerate(rows, 1):
        if i % 500 == 0:
            print(f"[stix]   {i:,}/{total:,} done")
        try:
            raw = _clean(r["value"])
            value = raw.replace("\\", "\\\\").replace("'", "\\'")
            ind = Indicator(
                id=_id("indicator", f"{r['type']}:{raw}"),
                created_by_ref=me.id, name=f"{r['type']}: {raw[:120]}",
                pattern=PATTERNS[r["type"]].format(value), pattern_type="stix",
                valid_from=_ts(r["first_seen"]), confidence=max(0, min(100, int(r["confidence"] or 50))),
                indicator_types=["malicious-activity"],
                labels=[f"source:{s}" for s in str(r["sources"]).split(",") if s],
                description=f"Seen by: {r['sources']}. Threat type: {r['threat_type'] or 'n/a'}.")
            out.append(_to_dict(ind))
        except Exception as e:  # bad value from a feed: skip it, keep going
            skipped += 1
            first_error = first_error or f"{r['type']} {str(r['value'])[:80]!r}: {e}"
            continue

        fam = r["malware_family"]
        if fam:
            fam = _clean(fam)
            if fam not in malware:
                malware[fam] = Malware(id=_id("malware", fam.lower()), name=fam, is_family=True,
                                       created_by_ref=me.id)
            rels.add(("indicates", ind.id, malware[fam].id))

        for t in conn.execute("SELECT * FROM ioc_techniques WHERE ioc_id=?", (r["id"],)):
            tid = t["technique_id"]
            if tid not in patterns:
                patterns[tid] = AttackPattern(
                    id=_id("attack-pattern", tid), name=t["technique_name"] or tid,
                    created_by_ref=me.id,
                    external_references=[{"source_name": "mitre-attack", "external_id": tid,
                                          "url": f"https://attack.mitre.org/techniques/{tid.replace('.', '/')}/"}])
            src = malware[fam].id if fam else ind.id
            rels.add(("uses" if fam else "indicates", src, patterns[tid].id))

    out += [_to_dict(m) for m in malware.values()] + [_to_dict(p) for p in patterns.values()]
    out += [_to_dict(Relationship(id=_id("relationship", f"{a}|{b}|{c}"), relationship_type=a,
                                  source_ref=b, target_ref=c, created_by_ref=me.id))
            for a, b, c in sorted(rels)]

    bundle = {"type": "bundle", "id": f"bundle--{uuid.uuid4()}", "objects": out}
    path = OUTPUT_DIR / f"stix_bundle_{datetime.now(timezone.utc):%Y%m%d}.json"
    path.write_text(json.dumps(bundle, indent=2, default=str), encoding="utf-8")
    print(f"[stix] {total - skipped:,} indicators, {len(malware)} malware, {len(patterns)} techniques, "
          f"{len(rels)} relationships -> {path.name}")
    if skipped:
        print(f"[stix] skipped {skipped} indicator(s) that could not be converted. First one: {first_error}")
    return path
