# Open-Source Threat Intelligence & IOC Enrichment Dashboard

Automated pipeline that collects malicious indicators (IOCs) from AlienVault OTX and abuse.ch
(ThreatFox, URLhaus, MalwareBazaar), deduplicates and enriches them, maps them to MITRE ATT&CK,
exports STIX 2.1 bundles, and visualizes everything in a Streamlit dashboard.

## Architecture

```
 OTX ─┐
 ThreatFox ─┤   collectors/    normalize +     attack_map.py    enrich.py        stix_export.py
 URLhaus ───┼─► (raw JSON) ──► dedupe (db.py) ─► ATT&CK mapping ─► GeoIP/ASN, ──► STIX 2.1 bundle
 MalwareBazaar┘                SQLite                             AbuseIPDB,         │
                                  │                               confidence score   │
                                  └──────────────► dashboard.py (Streamlit) ◄────────┘
```

## Quick start

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate     Mac/Linux: source .venv/bin/activate
pip install -r requirements.txt

python pipeline.py --demo        # fake sample data, no keys needed
streamlit run dashboard.py       # opens http://localhost:8501
```

## Using real feeds

1. Get free keys:
   - OTX: sign up at https://otx.alienvault.com, then Settings → API Key.
     Subscribe to a few active pulses/users so your feed isn't empty.
   - abuse.ch: https://auth.abuse.ch (one Auth-Key covers ThreatFox, URLhaus, MalwareBazaar).
   - AbuseIPDB (optional): https://www.abuseipdb.com/account/api
2. Copy `.env.example` to `.env` and paste the keys in.
3. Delete `data/threatintel.db` to clear the demo data.
4. Run `python pipeline.py --days 3` (first run pulls 3 days), then daily `python pipeline.py`.

The pipeline prints a summary at the end (unique IOCs, ATT&CK techniques covered, etc.).

## How each part works

| Step | File | What it does |
|---|---|---|
| Collect | `collectors/*.py` | Calls each feed's REST API, saves raw JSON to `data/raw/` |
| Normalize & dedupe | `db.py` | One row per (value, type); merges sources, tags, earliest/latest sighting |
| ATT&CK mapping | `attack_map.py` | Uses technique IDs from OTX pulses directly; otherwise maps malware family → ATT&CK software → techniques it "uses" |
| Enrichment | `enrich.py` | GeoIP/ASN via ip-api.com batch, reputation via AbuseIPDB, then confidence score |
| STIX export | `stix_export.py` | Indicator, Malware, Attack-Pattern, Relationship objects with deterministic IDs |
| Dashboard | `dashboard.py` | Trends, top families, ATT&CK tactic coverage, infrastructure, IOC search, CSV/STIX download |

**Confidence score:** best feed confidence, +10 per additional feed (max +20),
+10 if AbuseIPDB ≥ 75, +5 if the malware family is known, capped at 100.

## Run it automatically every day

- **Mac/Linux (cron):** `crontab -e` then add
  `0 6 * * * cd /path/to/threat-intel-dashboard && .venv/bin/python pipeline.py >> data/cron.log 2>&1`
- **Windows:** Task Scheduler → Create Basic Task → Daily → Program: `.venv\Scripts\python.exe`,
  Arguments: `pipeline.py`, Start in: the project folder.

## Optional add-ons

**Grafana:** install the "SQLite" data source plugin (`frser-sqlite-datasource`), point it at
`data/threatintel.db`, and build time-series panels, for example:
```sql
SELECT date(first_seen) AS time, COUNT(*) AS iocs FROM iocs GROUP BY 1 ORDER BY 1;
```

**TAXII 2.1:** run the open-source `medallion` TAXII server (`pip install medallion`) and load
the bundles from `output/` into a collection so other tools can poll them.

**OpenCTI:** run it with Docker (needs ~16 GB RAM) and import the STIX bundle from `output/`
through the web UI (Data → Import) or the `pycti` library.

## Data notes

Demo mode uses reserved documentation IP ranges (192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24)
and `.example` domains, so none of it is a real indicator. Real IOCs from these feeds are live
malicious infrastructure: don't visit the URLs or download the samples.
