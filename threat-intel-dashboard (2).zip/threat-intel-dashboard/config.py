"""Central settings. Reads API keys from the .env file."""
import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
OUTPUT_DIR = BASE_DIR / "output"
DB_PATH = DATA_DIR / "threatintel.db"
ATTACK_JSON = DATA_DIR / "enterprise-attack.json"
ATTACK_URL = ("https://raw.githubusercontent.com/mitre-attack/attack-stix-data/"
              "master/enterprise-attack/enterprise-attack.json")

OTX_API_KEY = os.getenv("OTX_API_KEY", "").strip()
ABUSECH_AUTH_KEY = os.getenv("ABUSECH_AUTH_KEY", "").strip()
ABUSEIPDB_API_KEY = os.getenv("ABUSEIPDB_API_KEY", "").strip()
ENRICH_LIMIT = int(os.getenv("ENRICH_LIMIT", "40"))

for d in (DATA_DIR, RAW_DIR, OUTPUT_DIR):
    d.mkdir(parents=True, exist_ok=True)
