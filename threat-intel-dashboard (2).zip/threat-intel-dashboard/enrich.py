"""Enrichment: GeoIP/ASN (ip-api.com batch, no key) + AbuseIPDB reputation (optional key),
then a confidence score for every IOC."""
import time
import requests
from config import ABUSEIPDB_API_KEY, ENRICH_LIMIT

GEO_BATCH_URL = "http://ip-api.com/batch?fields=status,query,countryCode,as"
ABUSEIPDB_URL = "https://api.abuseipdb.com/api/v2/check"


def enrich_ips(conn, limit=ENRICH_LIMIT):
    rows = conn.execute(
        """SELECT id, value FROM iocs WHERE type='ipv4' AND enriched=0
           ORDER BY source_conf DESC, first_seen DESC LIMIT ?""", (limit,)).fetchall()
    if not rows:
        print("[enrich] nothing new to enrich")
        return 0

    geo = {}
    try:  # one request for up to 100 IPs
        r = requests.post(GEO_BATCH_URL, json=[row["value"] for row in rows[:100]], timeout=30)
        r.raise_for_status()
        geo = {g["query"]: g for g in r.json() if g.get("status") == "success"}
    except requests.RequestException as e:
        print(f"[enrich] geo lookup failed: {e}")

    for row in rows:
        g = geo.get(row["value"], {})
        abuse = _abuseipdb(row["value"])
        conn.execute("UPDATE iocs SET country=?, asn=?, abuse_score=?, enriched=1 WHERE id=?",
                     (g.get("countryCode"), g.get("as"), abuse, row["id"]))
    print(f"[enrich] enriched {len(rows)} IPs"
          + ("" if ABUSEIPDB_API_KEY else " (geo only; add ABUSEIPDB_API_KEY for reputation)"))
    return len(rows)


def _abuseipdb(ip):
    if not ABUSEIPDB_API_KEY:
        return None
    try:
        r = requests.get(ABUSEIPDB_URL, params={"ipAddress": ip, "maxAgeInDays": 90},
                         headers={"Key": ABUSEIPDB_API_KEY, "Accept": "application/json"},
                         timeout=20)
        if r.status_code == 429:
            print("[enrich] AbuseIPDB daily limit reached")
            return None
        r.raise_for_status()
        time.sleep(0.2)
        return r.json()["data"]["abuseConfidenceScore"]
    except (requests.RequestException, KeyError):
        return None


def score_confidence(conn):
    """Score = best feed confidence, +10 for each extra feed that saw it (max +20),
    +10 if AbuseIPDB rates it 75+, +5 if we know the malware family. Capped at 100."""
    conn.execute("""
        UPDATE iocs SET confidence = MIN(100,
            source_conf
            + MIN(20, 10 * (LENGTH(sources) - LENGTH(REPLACE(sources, ',', ''))))
            + CASE WHEN abuse_score >= 75 THEN 10 ELSE 0 END
            + CASE WHEN malware_family IS NOT NULL THEN 5 ELSE 0 END)
    """)
