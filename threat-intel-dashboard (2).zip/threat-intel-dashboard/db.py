"""SQLite storage: one row per unique IOC, plus its ATT&CK techniques."""
import sqlite3
from contextlib import contextmanager
from config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS iocs (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    value          TEXT NOT NULL,
    type           TEXT NOT NULL,          -- ipv4 | domain | url | sha256 | md5
    first_seen     TEXT,
    last_seen      TEXT,
    malware_family TEXT,
    threat_type    TEXT,
    tags           TEXT,                   -- comma separated
    sources        TEXT,                   -- comma separated feed names
    source_conf    INTEGER DEFAULT 50,     -- highest confidence reported by a feed
    confidence     INTEGER DEFAULT 50,     -- our computed score 0-100
    country        TEXT,
    asn            TEXT,
    abuse_score    INTEGER,
    enriched       INTEGER DEFAULT 0,
    UNIQUE(value, type)
);
CREATE TABLE IF NOT EXISTS ioc_techniques (
    ioc_id         INTEGER NOT NULL,
    technique_id   TEXT NOT NULL,
    technique_name TEXT,
    tactic         TEXT,
    mapped_via     TEXT,                   -- 'feed' or 'malware-family'
    UNIQUE(ioc_id, technique_id, tactic)
);
CREATE INDEX IF NOT EXISTS idx_iocs_family ON iocs(malware_family);
CREATE INDEX IF NOT EXISTS idx_iocs_first_seen ON iocs(first_seen);
"""


@contextmanager
def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with connect() as conn:
        conn.executescript(SCHEMA)


def _merge_csv(old, new):
    items = {x.strip() for x in (old or "").split(",") if x.strip()}
    items |= {x.strip() for x in (new or "").split(",") if x.strip()}
    return ",".join(sorted(items))


def upsert_ioc(conn, ioc):
    """Insert a normalized IOC, or merge it into the existing row (deduplication)."""
    row = conn.execute("SELECT * FROM iocs WHERE value=? AND type=?",
                       (ioc["value"], ioc["type"])).fetchone()
    if row is None:
        cur = conn.execute(
            """INSERT INTO iocs (value, type, first_seen, last_seen, malware_family,
               threat_type, tags, sources, source_conf)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (ioc["value"], ioc["type"], ioc["first_seen"], ioc["first_seen"],
             ioc.get("malware_family"), ioc.get("threat_type"), ioc.get("tags", ""),
             ioc["source"], ioc.get("source_conf", 50)))
        ioc_id = cur.lastrowid
    else:
        ioc_id = row["id"]
        conn.execute(
            """UPDATE iocs SET
                 first_seen = MIN(first_seen, ?), last_seen = MAX(last_seen, ?),
                 malware_family = COALESCE(malware_family, ?),
                 threat_type = COALESCE(threat_type, ?),
                 tags = ?, sources = ?, source_conf = MAX(source_conf, ?)
               WHERE id = ?""",
            (ioc["first_seen"], ioc["first_seen"], ioc.get("malware_family"),
             ioc.get("threat_type"), _merge_csv(row["tags"], ioc.get("tags")),
             _merge_csv(row["sources"], ioc["source"]), ioc.get("source_conf", 50), ioc_id))

    for t in ioc.get("attack_ids", []):  # techniques the feed itself supplied
        conn.execute(
            """INSERT OR IGNORE INTO ioc_techniques
               (ioc_id, technique_id, technique_name, tactic, mapped_via)
               VALUES (?,?,?,?, 'feed')""",
            (ioc_id, t["id"], t.get("name"), t.get("tactic")))
    return ioc_id
