"""Streamlit dashboard.  Run:  streamlit run dashboard.py"""
import sqlite3
from datetime import timedelta
import pandas as pd
import plotly.express as px
import streamlit as st
from config import DB_PATH, OUTPUT_DIR
from attack_map import TACTIC_ORDER

st.set_page_config(page_title="Threat Intel Dashboard", page_icon="🛡️", layout="wide")

SOURCE_COLORS = {"threatfox": "#1F4E79", "urlhaus": "#C8553D", "malwarebazaar": "#5B8E7D",
                 "otx": "#E0A458"}
CHART = dict(template="plotly_white", margin=dict(l=10, r=10, t=40, b=10),
             font=dict(family="Inter, Segoe UI, sans-serif", size=13))


@st.cache_data(ttl=300)
def load():
    if not DB_PATH.exists():
        return None, None
    with sqlite3.connect(DB_PATH) as conn:
        iocs = pd.read_sql("SELECT * FROM iocs", conn, parse_dates=["first_seen", "last_seen"])
        tech = pd.read_sql("SELECT * FROM ioc_techniques", conn)
    iocs["primary_source"] = iocs["sources"].str.split(",").str[0]
    iocs["feed_count"] = iocs["sources"].str.count(",") + 1
    return iocs, tech


iocs, tech = load()
st.title("Threat Intelligence Dashboard")

if iocs is None or iocs.empty:
    st.info("No data yet. In a terminal, run `python pipeline.py --demo` to load sample data, "
            "or `python pipeline.py` with your API keys in `.env`, then refresh this page.")
    st.stop()

if (iocs["tags"].fillna("").str.contains("demo")).any():
    st.warning("Showing demo data. Run `python pipeline.py` with real API keys for live indicators.")

# ---------- filters ----------
with st.sidebar:
    st.header("Filters")
    max_day = iocs["first_seen"].max().date()
    min_day = iocs["first_seen"].min().date()
    start = st.date_input("From", max(min_day, max_day - timedelta(days=13)),
                          min_value=min_day, max_value=max_day)
    end = st.date_input("To", max_day, min_value=min_day, max_value=max_day)
    sources = st.multiselect("Feeds", sorted(SOURCE_COLORS), default=sorted(SOURCE_COLORS))
    types = st.multiselect("Indicator types", sorted(iocs["type"].unique()),
                           default=sorted(iocs["type"].unique()))
    min_conf = st.slider("Minimum confidence", 0, 100, 0, 5)
    if st.button("Reload data"):
        st.cache_data.clear()
        st.rerun()

mask = (iocs["first_seen"].dt.date.between(start, end) & iocs["type"].isin(types)
        & (iocs["confidence"] >= min_conf)
        & iocs["sources"].apply(lambda s: any(x in s.split(",") for x in sources)))
df = iocs[mask]
tf = tech[tech["ioc_id"].isin(df["id"])]

if df.empty:
    st.info("No indicators match these filters. Widen the date range or lower the confidence.")
    st.stop()

# ---------- headline numbers ----------
c1, c2, c3, c4, c5 = st.columns(5)
last24 = df[df["first_seen"] >= df["first_seen"].max() - timedelta(days=1)]
c1.metric("Indicators", f"{len(df):,}", f"+{len(last24):,} in last 24h")
c2.metric("Malware families", df["malware_family"].nunique())
c3.metric("ATT&CK techniques", tf["technique_id"].nunique())
c4.metric("High confidence (≥80)", f"{(df['confidence'] >= 80).sum():,}")
c5.metric("Seen by 2+ feeds", f"{(df['feed_count'] > 1).sum():,}")

# ---------- trend + families ----------
left, right = st.columns([3, 2])
daily = (df.assign(day=df["first_seen"].dt.date)
           .groupby(["day", "primary_source"]).size().reset_index(name="count"))
fig = px.bar(daily, x="day", y="count", color="primary_source", title="New indicators per day",
             color_discrete_map=SOURCE_COLORS, labels={"day": "", "count": "Indicators",
                                                       "primary_source": "Feed"})
fig.update_layout(**CHART, legend=dict(orientation="h", y=-0.15))
left.plotly_chart(fig, width="stretch")

fam = (df.dropna(subset=["malware_family"])["malware_family"].value_counts()
         .head(10).sort_values().reset_index())
fam.columns = ["family", "count"]
fig = px.bar(fam, x="count", y="family", orientation="h", title="Most active malware families",
             labels={"family": "", "count": "Indicators"}, color_discrete_sequence=["#1F4E79"])
fig.update_layout(**CHART)
right.plotly_chart(fig, width="stretch")

# ---------- ATT&CK ----------
st.subheader("MITRE ATT&CK coverage")
left, right = st.columns([2, 3])
tac = (tf[tf["tactic"].isin(TACTIC_ORDER)].groupby("tactic")["technique_id"].nunique()
         .reindex(TACTIC_ORDER, fill_value=0).reset_index())
tac.columns = ["tactic", "techniques"]
tac["tactic"] = tac["tactic"].str.replace("-", " ").str.capitalize()
fig = px.bar(tac, x="techniques", y="tactic", orientation="h",
             title="Techniques observed per tactic (kill-chain order)",
             labels={"tactic": "", "techniques": "Distinct techniques"},
             color_discrete_sequence=["#C8553D"])
fig.update_layout(**CHART, yaxis=dict(autorange="reversed"))
left.plotly_chart(fig, width="stretch")

top_tech = (tf.groupby(["technique_id", "technique_name"])
              .agg(indicators=("ioc_id", "nunique"), tactics=("tactic", lambda s: ", ".join(sorted(set(s)))))
              .sort_values("indicators", ascending=False).head(15).reset_index())
top_tech["link"] = "https://attack.mitre.org/techniques/" + top_tech["technique_id"].str.replace(".", "/", regex=False) + "/"
right.markdown("**Top techniques linked to current indicators**")
right.dataframe(top_tech, hide_index=True, width="stretch", height=420,
                column_config={"link": st.column_config.LinkColumn("ATT&CK", display_text="Open"),
                               "technique_id": "ID", "technique_name": "Technique"})

# ---------- infrastructure ----------
ips = df[(df["type"] == "ipv4") & df["country"].notna()]
if not ips.empty:
    st.subheader("Attacker infrastructure (enriched IPs)")
    left, right = st.columns(2)
    cc = ips["country"].value_counts().head(12).sort_values().reset_index()
    cc.columns = ["country", "count"]
    fig = px.bar(cc, x="count", y="country", orientation="h", title="Hosting country",
                 labels={"country": "", "count": "IPs"}, color_discrete_sequence=["#5B8E7D"])
    fig.update_layout(**CHART)
    left.plotly_chart(fig, width="stretch")
    if ips["abuse_score"].notna().any():
        fig = px.histogram(ips, x="abuse_score", nbins=10, title="AbuseIPDB reputation score",
                           labels={"abuse_score": "Abuse confidence (0-100)"},
                           color_discrete_sequence=["#E0A458"])
        fig.update_layout(**CHART, yaxis_title="IPs")
        right.plotly_chart(fig, width="stretch")

# ---------- IOC search ----------
st.subheader("Indicator search")
q = st.text_input("Search by value, family, or tag", placeholder="e.g. Cobalt Strike, 203.0.113, .example")
view = df
if q:
    ql = q.lower()
    view = df[df["value"].str.lower().str.contains(ql, regex=False)
              | df["malware_family"].fillna("").str.lower().str.contains(ql, regex=False)
              | df["tags"].fillna("").str.contains(ql, regex=False)]
cols = ["value", "type", "malware_family", "threat_type", "confidence", "sources",
        "first_seen", "country", "abuse_score"]
st.dataframe(view.sort_values("first_seen", ascending=False)[cols], hide_index=True,
             width="stretch", height=380,
             column_config={"confidence": st.column_config.ProgressColumn(
                 "Confidence", min_value=0, max_value=100, format="%d")})

# ---------- exports ----------
d1, d2 = st.columns(2)
d1.download_button("Download filtered IOCs (CSV)", view[cols].to_csv(index=False),
                   "iocs.csv", "text/csv", width="stretch")
bundles = sorted(OUTPUT_DIR.glob("stix_bundle_*.json"))
if bundles:
    d2.download_button(f"Download latest STIX 2.1 bundle ({bundles[-1].name})",
                       bundles[-1].read_bytes(), bundles[-1].name, "application/json",
                       width="stretch")
