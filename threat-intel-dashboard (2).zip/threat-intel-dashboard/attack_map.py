"""Map IOCs to MITRE ATT&CK.
1) Techniques the feed already supplied (OTX pulses) get their tactic filled in.
2) IOCs with a known malware family inherit the techniques ATT&CK says that family uses."""
import json
import re
import requests
from config import ATTACK_JSON, ATTACK_URL

TACTIC_ORDER = ["reconnaissance", "resource-development", "initial-access", "execution",
                "persistence", "privilege-escalation", "defense-evasion", "credential-access",
                "discovery", "lateral-movement", "collection", "command-and-control",
                "exfiltration", "impact"]


def _key(name):
    name = re.sub(r"^(win|elf|osx|apk|jar|js|ps1)\.", "", name.lower())
    return re.sub(r"[^a-z0-9]", "", name)


class Attack:
    def __init__(self):
        if not ATTACK_JSON.exists():
            print("[attack] downloading ATT&CK Enterprise data (~40 MB, first run only)...")
            r = requests.get(ATTACK_URL, timeout=180)
            r.raise_for_status()
            ATTACK_JSON.write_bytes(r.content)
        objs = json.loads(ATTACK_JSON.read_text(encoding="utf-8"))["objects"]

        live = lambda o: not o.get("revoked") and not o.get("x_mitre_deprecated")
        self.techniques = {}   # stix id -> (T-id, name, [tactics])
        self.by_tid = {}       # T-id -> (name, [tactics])
        for o in objs:
            if o["type"] == "attack-pattern" and live(o):
                tid = next((r["external_id"] for r in o.get("external_references", [])
                            if r.get("source_name") == "mitre-attack"), None)
                if tid:
                    tactics = [p["phase_name"] for p in o.get("kill_chain_phases", [])
                               if p.get("kill_chain_name") == "mitre-attack"]
                    self.techniques[o["id"]] = (tid, o["name"], tactics)
                    self.by_tid[tid] = (o["name"], tactics)

        self.software = {}     # normalized name/alias -> stix id
        for o in objs:
            if o["type"] in ("malware", "tool") and live(o):
                for n in [o["name"]] + o.get("x_mitre_aliases", []):
                    self.software.setdefault(_key(n), o["id"])

        self.uses = {}         # software stix id -> [technique stix ids]
        for o in objs:
            if (o["type"] == "relationship" and o.get("relationship_type") == "uses" and live(o)
                    and o["target_ref"].startswith("attack-pattern--")
                    and o["source_ref"].split("--")[0] in ("malware", "tool")):
                self.uses.setdefault(o["source_ref"], []).append(o["target_ref"])
        print(f"[attack] loaded {len(self.by_tid)} techniques, {len(self.software)} software names")

    def techniques_for_family(self, family):
        sw = self.software.get(_key(family or ""))
        return [self.techniques[t] for t in self.uses.get(sw, []) if t in self.techniques]


def map_all(conn, attack):
    # 1) fill tactics for feed-supplied technique IDs
    for row in conn.execute("SELECT * FROM ioc_techniques WHERE tactic IS NULL").fetchall():
        name, tactics = attack.by_tid.get(row["technique_id"], (row["technique_name"], ["unknown"]))
        for tac in tactics or ["unknown"]:
            conn.execute("""INSERT OR IGNORE INTO ioc_techniques VALUES (?,?,?,?,?)""",
                         (row["ioc_id"], row["technique_id"], name, tac, row["mapped_via"]))
    conn.execute("DELETE FROM ioc_techniques WHERE tactic IS NULL")

    # 2) family-based mapping
    cache, mapped = {}, 0
    rows = conn.execute("""SELECT id, malware_family FROM iocs WHERE malware_family IS NOT NULL
                           AND id NOT IN (SELECT DISTINCT ioc_id FROM ioc_techniques)""").fetchall()
    for row in rows:
        fam = row["malware_family"]
        if fam not in cache:
            cache[fam] = attack.techniques_for_family(fam)
        for tid, name, tactics in cache[fam]:
            for tac in tactics:
                conn.execute("INSERT OR IGNORE INTO ioc_techniques VALUES (?,?,?,?, 'malware-family')",
                             (row["id"], tid, name, tac))
        mapped += bool(cache[fam])
    known = sum(1 for v in cache.values() if v)
    print(f"[attack] mapped {mapped} IOCs; {known}/{len(cache)} malware families found in ATT&CK")
