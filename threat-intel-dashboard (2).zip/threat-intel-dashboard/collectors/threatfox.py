"""abuse.ch ThreatFox: IOCs tied to malware families, with a confidence level."""
import requests
from config import ABUSECH_AUTH_KEY
from .common import save_raw, norm_date, clean_family, tags_csv

URL = "https://threatfox-api.abuse.ch/api/v1/"
TYPE_MAP = {"ip:port": "ipv4", "domain": "domain", "url": "url",
            "sha256_hash": "sha256", "md5_hash": "md5"}


def collect(days=1):
    if not ABUSECH_AUTH_KEY:
        print("[threatfox] skipped: ABUSECH_AUTH_KEY not set in .env")
        return []
    r = requests.post(URL, json={"query": "get_iocs", "days": days},
                      headers={"Auth-Key": ABUSECH_AUTH_KEY}, timeout=60)
    r.raise_for_status()
    data = r.json()
    save_raw("threatfox", data)
    if data.get("query_status") != "ok":
        print(f"[threatfox] API said: {data.get('query_status')}")
        return []

    out = []
    for row in data.get("data") or []:
        t = TYPE_MAP.get(row.get("ioc_type"))
        if not t:
            continue
        value = row["ioc"].strip()
        if t == "ipv4":
            value = value.split(":")[0]  # drop the port
        out.append({
            "value": value, "type": t, "first_seen": norm_date(row.get("first_seen")),
            "malware_family": clean_family(row.get("malware_printable")),
            "threat_type": row.get("threat_type"), "tags": tags_csv(row.get("tags")),
            "source": "threatfox", "source_conf": int(row.get("confidence_level") or 50),
        })
    print(f"[threatfox] {len(out)} indicators")
    return out
