"""AlienVault OTX: pulses you are subscribed to (subscribe to a few users/pulses on the site)."""
from datetime import datetime, timedelta, timezone
import requests
from config import OTX_API_KEY
from .common import save_raw, norm_date, clean_family, tags_csv

URL = "https://otx.alienvault.com/api/v1/pulses/subscribed"
TYPE_MAP = {"IPv4": "ipv4", "domain": "domain", "hostname": "domain", "URL": "url",
            "FileHash-SHA256": "sha256", "FileHash-MD5": "md5"}


def collect(days=7, max_pages=5):
    if not OTX_API_KEY:
        print("[otx] skipped: OTX_API_KEY not set in .env")
        return []
    since = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S")
    headers = {"X-OTX-API-KEY": OTX_API_KEY}
    url, params, pulses = URL, {"modified_since": since, "limit": 50}, []
    for _ in range(max_pages):
        r = requests.get(url, headers=headers, params=params, timeout=60)
        r.raise_for_status()
        data = r.json()
        pulses.extend(data.get("results", []))
        url, params = data.get("next"), None
        if not url:
            break
    save_raw("otx", pulses)

    out = []
    for p in pulses:
        fams = p.get("malware_families") or []
        family = clean_family(fams[0].get("display_name") if fams and isinstance(fams[0], dict)
                              else (fams[0] if fams else None))
        attack_ids = [{"id": a.get("id"), "name": a.get("name")}
                      for a in (p.get("attack_ids") or []) if isinstance(a, dict) and a.get("id")]
        for ind in p.get("indicators", []):
            t = TYPE_MAP.get(ind.get("type"))
            if not t:
                continue
            out.append({
                "value": ind["indicator"].strip(), "type": t,
                "first_seen": norm_date(ind.get("created")),
                "malware_family": family, "threat_type": None,
                "tags": tags_csv(p.get("tags")), "source": "otx",
                "source_conf": 60, "attack_ids": attack_ids,
            })
    print(f"[otx] {len(pulses)} pulses -> {len(out)} indicators")
    return out
