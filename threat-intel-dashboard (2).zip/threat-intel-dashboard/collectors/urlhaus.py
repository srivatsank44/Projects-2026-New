"""abuse.ch URLhaus: URLs currently distributing malware."""
import requests
from config import ABUSECH_AUTH_KEY
from .common import save_raw, norm_date, tags_csv

URL = "https://urlhaus-api.abuse.ch/v1/urls/recent/limit/500/"


def collect():
    if not ABUSECH_AUTH_KEY:
        print("[urlhaus] skipped: ABUSECH_AUTH_KEY not set in .env")
        return []
    r = requests.get(URL, headers={"Auth-Key": ABUSECH_AUTH_KEY}, timeout=60)
    r.raise_for_status()
    data = r.json()
    save_raw("urlhaus", data)
    if data.get("query_status") != "ok":
        print(f"[urlhaus] API said: {data.get('query_status')}")
        return []

    out = []
    for row in data.get("urls") or []:
        tags = row.get("tags") or []
        # URLhaus tags often contain the family name (e.g. 'Mozi', 'AgentTesla')
        family = next((t for t in tags if t and t[0].isupper() and t.lower() not in
                       {"elf", "exe", "doc", "zip", "rar", "js", "32-bit", "64-bit", "arm", "mips"}),
                      None)
        out.append({
            "value": row["url"].strip(), "type": "url",
            "first_seen": norm_date(row.get("date_added")), "malware_family": family,
            "threat_type": row.get("threat"), "tags": tags_csv(tags),
            "source": "urlhaus", "source_conf": 75 if row.get("url_status") == "online" else 55,
        })
    print(f"[urlhaus] {len(out)} indicators")
    return out
