"""Shared helpers for all collectors."""
import json
import re
from datetime import datetime, timezone
from config import RAW_DIR

HASH_RE = {"sha256": re.compile(r"^[a-fA-F0-9]{64}$"), "md5": re.compile(r"^[a-fA-F0-9]{32}$")}
IP_RE = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def save_raw(source, payload):
    """Keep the untouched API response so you can re-process without re-downloading."""
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = RAW_DIR / f"{source}_{stamp}.json"
    path.write_text(json.dumps(payload, indent=1))
    return path


def norm_date(value):
    """Turn the many date formats the feeds use into 'YYYY-MM-DD HH:MM:SS' (UTC)."""
    if not value:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    value = str(value).replace("T", " ").replace("Z", "").replace(" UTC", "")
    return value.split(".")[0][:19]


def clean_family(name):
    if not name or str(name).strip().lower() in {"none", "null", "n/a", "-"}:
        return None
    if str(name).strip().lower().startswith("unknown"):  # "Unknown Loader", "Unknown malware"
        return None
    return str(name).strip()


def tags_csv(tags):
    if not tags:
        return ""
    if isinstance(tags, str):
        tags = tags.split(",")
    return ",".join(sorted({str(t).strip().lower() for t in tags if t}))
