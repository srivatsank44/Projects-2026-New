###############################################################################
# GuardDuty: managed threat detection over CloudTrail, VPC Flow Logs and DNS.
# Note: GuardDuty is regional. If a detector already exists in this region,
# import it first:  terraform import aws_guardduty_detector.main <detector-id>
###############################################################################

resource "aws_guardduty_detector" "main" {
  enable = true

  # New findings reach EventBridge within ~5 minutes regardless of this value;
  # this controls how often *updates* to existing findings are published.
  finding_publishing_frequency = "FIFTEEN_MINUTES"
}

resource "aws_guardduty_detector_feature" "s3_protection" {
  count       = var.enable_s3_protection ? 1 : 0
  detector_id = aws_guardduty_detector.main.id
  name        = "S3_DATA_EVENTS"
  status      = "ENABLED"
}
