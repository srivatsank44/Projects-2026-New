###############################################################################
# Alerting pipeline
#   Path A: GuardDuty finding (sev >= threshold) -> EventBridge -> SNS -> email
#   Path B: CloudTrail -> CloudWatch Logs -> metric filter -> alarm -> SNS
###############################################################################

# -------------------------------------------------------------------- SNS
# Left unencrypted on purpose: an SNS topic encrypted with the AWS-managed
# key cannot receive messages from EventBridge or CloudWatch. Use a customer
# managed KMS key with a matching key policy if you need encryption.
resource "aws_sns_topic" "alerts" {
  name = "${var.project_name}-security-alerts"
}

resource "aws_sns_topic_subscription" "email" {
  topic_arn = aws_sns_topic.alerts.arn
  protocol  = "email"
  endpoint  = var.alert_email
}

data "aws_iam_policy_document" "sns" {
  statement {
    sid = "AccountOwnerFullControl"
    actions = [
      "SNS:Publish", "SNS:Subscribe", "SNS:Receive", "SNS:GetTopicAttributes",
      "SNS:SetTopicAttributes", "SNS:ListSubscriptionsByTopic",
      "SNS:AddPermission", "SNS:RemovePermission", "SNS:DeleteTopic",
    ]
    resources = [aws_sns_topic.alerts.arn]
    principals {
      type        = "AWS"
      identifiers = ["arn:${local.partition}:iam::${local.account_id}:root"]
    }
  }

  statement {
    sid       = "AllowEventBridgePublish"
    actions   = ["sns:Publish"]
    resources = [aws_sns_topic.alerts.arn]
    principals {
      type        = "Service"
      identifiers = ["events.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [local.account_id]
    }
  }

  statement {
    sid       = "AllowCloudWatchAlarmsPublish"
    actions   = ["sns:Publish"]
    resources = [aws_sns_topic.alerts.arn]
    principals {
      type        = "Service"
      identifiers = ["cloudwatch.amazonaws.com"]
    }
    condition {
      test     = "ArnLike"
      variable = "aws:SourceArn"
      values   = ["arn:${local.partition}:cloudwatch:${var.aws_region}:${local.account_id}:alarm:*"]
    }
  }
}

resource "aws_sns_topic_policy" "alerts" {
  arn    = aws_sns_topic.alerts.arn
  policy = data.aws_iam_policy_document.sns.json
}

# ------------------------------------------- Path A: GuardDuty -> EventBridge
resource "aws_cloudwatch_event_rule" "guardduty_high" {
  name        = "${var.project_name}-guardduty-high-severity"
  description = "GuardDuty findings with severity >= ${var.guardduty_min_severity}"

  event_pattern = jsonencode({
    source        = ["aws.guardduty"]
    "detail-type" = ["GuardDuty Finding"]
    detail = {
      severity = [{ numeric = [">=", var.guardduty_min_severity] }]
    }
  })
}

resource "aws_cloudwatch_event_target" "guardduty_to_sns" {
  rule      = aws_cloudwatch_event_rule.guardduty_high.name
  target_id = "security-alerts-sns"
  arn       = aws_sns_topic.alerts.arn

  # Turns the raw finding JSON into a compact, readable alert email.
  input_transformer {
    input_paths = {
      severity    = "$.detail.severity"
      type        = "$.detail.type"
      title       = "$.detail.title"
      description = "$.detail.description"
      account     = "$.detail.accountId"
      region      = "$.detail.region"
      resource    = "$.detail.resource.resourceType"
      id          = "$.detail.id"
      time        = "$.detail.updatedAt"
    }
    input_template = <<-EOT
      {
        "alert": "GuardDuty high-severity finding",
        "severity": <severity>,
        "finding_type": <type>,
        "title": <title>,
        "description": <description>,
        "resource_type": <resource>,
        "account": <account>,
        "region": <region>,
        "last_seen": <time>,
        "console": "https://console.aws.amazon.com/guardduty/home?region=<region>#/findings?fId=<id>"
      }
    EOT
  }

  depends_on = [aws_sns_topic_policy.alerts]
}

# ------------------------------- Path B: CloudTrail metric filters + alarms
# Patterns follow the CIS AWS Foundations Benchmark monitoring controls,
# plus a few lab-specific ones. 8 alarms stays inside the 10-alarm free tier.
locals {
  detections = {
    RootAccountUsage = {
      description = "Any API or console activity by the root user"
      pattern     = "{ $.userIdentity.type = \"Root\" && $.userIdentity.invokedBy NOT EXISTS && $.eventType != \"AwsServiceEvent\" }"
      threshold   = 1
    }
    ConsoleLoginWithoutMFA = {
      description = "Successful console sign-in without MFA (root or IAM user)"
      pattern     = "{ ($.eventName = \"ConsoleLogin\") && ($.additionalEventData.MFAUsed != \"Yes\") && ($.responseElements.ConsoleLogin = \"Success\") }"
      threshold   = 1
    }
    S3BucketPolicyChanges = {
      description = "Bucket policy, ACL or public-access-block changes"
      pattern     = "{ ($.eventSource = \"s3.amazonaws.com\") && (($.eventName = \"PutBucketAcl\") || ($.eventName = \"PutBucketPolicy\") || ($.eventName = \"DeleteBucketPolicy\") || ($.eventName = \"PutBucketCors\") || ($.eventName = \"PutBucketReplication\") || ($.eventName = \"PutBucketPublicAccessBlock\") || ($.eventName = \"DeleteBucketPublicAccessBlock\")) }"
      threshold   = 1
    }
    IAMPolicyChanges = {
      description = "IAM policy creation, attachment or modification"
      pattern     = "{ ($.eventName = \"DeleteGroupPolicy\") || ($.eventName = \"DeleteRolePolicy\") || ($.eventName = \"DeleteUserPolicy\") || ($.eventName = \"PutGroupPolicy\") || ($.eventName = \"PutRolePolicy\") || ($.eventName = \"PutUserPolicy\") || ($.eventName = \"CreatePolicy\") || ($.eventName = \"DeletePolicy\") || ($.eventName = \"CreatePolicyVersion\") || ($.eventName = \"DeletePolicyVersion\") || ($.eventName = \"AttachRolePolicy\") || ($.eventName = \"DetachRolePolicy\") || ($.eventName = \"AttachUserPolicy\") || ($.eventName = \"DetachUserPolicy\") || ($.eventName = \"AttachGroupPolicy\") || ($.eventName = \"DetachGroupPolicy\") }"
      threshold   = 1
    }
    UnauthorizedAPICalls = {
      description = "Burst of AccessDenied / UnauthorizedOperation errors (recon or stolen keys)"
      pattern     = "{ ($.errorCode = \"*UnauthorizedOperation\") || ($.errorCode = \"AccessDenied*\") }"
      threshold   = 5
    }
    EC2InstanceLaunched = {
      description = "RunInstances in any region (flag unexpected compute / cryptomining)"
      pattern     = "{ ($.eventSource = \"ec2.amazonaws.com\") && ($.eventName = \"RunInstances\") }"
      threshold   = 1
    }
    CloudTrailTampering = {
      description = "Attempts to stop, delete or reconfigure CloudTrail"
      pattern     = "{ ($.eventName = \"StopLogging\") || ($.eventName = \"DeleteTrail\") || ($.eventName = \"UpdateTrail\") || ($.eventName = \"PutEventSelectors\") }"
      threshold   = 1
    }
    GuardDutyTampering = {
      description = "Attempts to disable GuardDuty or suppress its findings"
      pattern     = "{ ($.eventSource = \"guardduty.amazonaws.com\") && (($.eventName = \"DeleteDetector\") || ($.eventName = \"UpdateDetector\") || ($.eventName = \"CreateFilter\") || ($.eventName = \"CreateIPSet\")) }"
      threshold   = 1
    }
  }

  metric_namespace = "CloudThreatLab"
}

resource "aws_cloudwatch_log_metric_filter" "detections" {
  for_each       = local.detections
  name           = "${var.project_name}-${each.key}"
  log_group_name = aws_cloudwatch_log_group.trail.name
  pattern        = each.value.pattern

  metric_transformation {
    name      = each.key
    namespace = local.metric_namespace
    value     = "1"
  }
}

resource "aws_cloudwatch_metric_alarm" "detections" {
  for_each = local.detections

  alarm_name          = "${var.project_name}-${each.key}"
  alarm_description   = each.value.description
  namespace           = local.metric_namespace
  metric_name         = each.key
  statistic           = "Sum"
  period              = 300
  evaluation_periods  = 1
  threshold           = each.value.threshold
  comparison_operator = "GreaterThanOrEqualToThreshold"
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alerts.arn]

  depends_on = [aws_cloudwatch_log_metric_filter.detections, aws_sns_topic_policy.alerts]
}
