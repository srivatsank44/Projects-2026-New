variable "aws_region" {
  description = "Home region for the trail, log group, GuardDuty detector and alerting."
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Prefix used for all resource names."
  type        = string
  default     = "cloud-threat-lab"

  validation {
    condition     = can(regex("^[a-z0-9-]{3,24}$", var.project_name))
    error_message = "Use 3-24 lowercase letters, digits or hyphens (it becomes part of an S3 bucket name)."
  }
}

variable "alert_email" {
  description = "Email address that receives SNS security alerts. You must confirm the subscription email."
  type        = string

  validation {
    condition     = can(regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$", var.alert_email))
    error_message = "alert_email must be a valid email address."
  }
}

variable "guardduty_min_severity" {
  description = "Minimum GuardDuty severity that triggers an email. 7.0+ = High, 4.0-6.9 = Medium."
  type        = number
  default     = 7
}

variable "log_retention_days" {
  description = "Retention for the CloudTrail CloudWatch log group."
  type        = number
  default     = 30
}

variable "trail_bucket_expiration_days" {
  description = "Days before CloudTrail log objects in S3 expire (keeps lab storage costs near zero)."
  type        = number
  default     = 90
}

variable "enable_s3_protection" {
  description = "Enable GuardDuty S3 Protection (needed for S3 policy findings such as Policy:S3/BucketAnonymousAccessGranted)."
  type        = bool
  default     = true
}
