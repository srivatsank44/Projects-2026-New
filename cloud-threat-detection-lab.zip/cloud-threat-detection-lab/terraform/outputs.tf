output "aws_region" {
  value = var.aws_region
}

output "cloudtrail_name" {
  value = aws_cloudtrail.main.name
}

output "cloudtrail_bucket" {
  value = aws_s3_bucket.trail.id
}

output "cloudtrail_log_group" {
  value = aws_cloudwatch_log_group.trail.name
}

output "guardduty_detector_id" {
  value = aws_guardduty_detector.main.id
}

output "sns_topic_arn" {
  value = aws_sns_topic.alerts.arn
}

output "alarms" {
  value = [for a in aws_cloudwatch_metric_alarm.detections : a.alarm_name]
}

output "next_step" {
  value = "Confirm the SNS subscription email sent to ${var.alert_email}, then run scripts/simulate_events.sh"
}
