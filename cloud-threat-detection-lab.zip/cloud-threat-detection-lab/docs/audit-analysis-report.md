# CloudTrail Audit Analysis — Simulated Cloud Intrusion

> Fill in the `<>` placeholders from your own run. Keep redacted screenshots in `docs/screenshots/`.
> Redact account IDs, access key IDs and your public IP before publishing to GitHub.

| Field | Value |
|---|---|
| Analyst | `<your name>` |
| Environment | AWS lab account `<redacted>`, home region `us-east-1` |
| Window analyzed | `<start UTC>` – `<end UTC>` |
| Data sources | CloudTrail (multi-region, management events), GuardDuty, CloudWatch alarms |
| Tools | CloudWatch Logs Insights, GuardDuty console, `aws cloudtrail validate-logs` |

## 1. Executive summary
`<3–4 sentences: what happened, how fast it was detected, what the biggest gap was.>`
Example: *Six adversary behaviors were simulated over ~25 minutes. Eight of eight CloudTrail
detections fired and GuardDuty raised a real high-severity C2 finding; median time from
event to email was `<X>` minutes. The main gap: S3 policy changes were only caught as a
generic change, not scored by risk.*

## 2. Detection coverage matrix

| # | Simulated behavior | MITRE ATT&CK | CloudTrail event(s) | Detection that fired | Event time | Alert time | MTTD |
|---|---|---|---|---|---|---|---|
| 1 | Public S3 bucket policy | T1530 | `DeleteBucketPublicAccessBlock`, `PutBucketPolicy` | `S3BucketPolicyChanges` alarm; GD `Policy:S3/BucketAnonymousAccessGranted` | | | |
| 2 | Backdoor admin user | T1136.003, T1098 | `CreateUser`, `AttachUserPolicy` | `IAMPolicyChanges` alarm | | | |
| 3 | Recon with low-priv key | T1580, T1078.004 | `ListBuckets`, `DescribeInstances` … (`AccessDenied`) | `UnauthorizedAPICalls` alarm | | | |
| 4 | Rogue EC2 instance | T1578.002 | `RunInstances` | `EC2InstanceLaunched` alarm | | | |
| 5 | DNS C2 from instance | T1071.004 | *(DNS logs, not CloudTrail)* | GD `Backdoor:EC2/C&CActivity.B!DNS` → email | | | |
| 6 | Console login w/o MFA | T1078 | `ConsoleLogin` (`MFAUsed: No`) | `ConsoleLoginWithoutMFA` (+ `RootAccountUsage` if root) | | | |
| 7 | Pipeline test | — | — | GD sample findings → email | | | |

## 3. Timeline of attacker activity
Built from Logs Insights query #8 (pivot on the actor).

| Time (UTC) | Actor | Source IP | Event | Region | Result | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

## 4. Findings in detail
Repeat this block for each behavior.

### 4.x `<Behavior name>`
**What happened:** `<plain-language description>`

**Evidence (trimmed CloudTrail record):**
```json
{
  "eventTime": "<>",
  "eventSource": "s3.amazonaws.com",
  "eventName": "PutBucketPolicy",
  "userIdentity": { "type": "IAMUser", "arn": "<redacted>" },
  "sourceIPAddress": "<redacted>",
  "requestParameters": { "bucketName": "lab-sim-public-…", "bucketPolicy": { "Statement": [{ "Principal": "*", "Action": "s3:GetObject" }] } }
}
```
**Key fields an analyst should check:** `userIdentity`, `sourceIPAddress`, `userAgent`,
`errorCode`, `requestParameters`, `awsRegion`.

**How it was detected:** `<alarm / finding name, screenshot link>`

**Risk if real:** `<impact>`

**Recommended control:** `<preventive fix, e.g. account-level S3 Block Public Access, SCP denying s3:PutBucketPolicy with Principal *>`

## 5. Gaps and false positives observed
- `<e.g. Terraform's own PutRolePolicy tripped IAMPolicyChanges during deploy — would need an allowlist for the CI role in production.>`
- `<e.g. GuardDuty didn't alert on the IAM backdoor user — managed detection isn't a substitute for custom rules.>`
- `<e.g. CloudTrail → CloudWatch delivery latency of ~X minutes bounds how fast custom alarms can fire.>`

## 6. Hardening recommendations
| Priority | Recommendation | Prevents |
|---|---|---|
| High | Enable MFA on root; lock root credentials away; alarm on any root use | #6 |
| High | Account-level S3 Block Public Access (and SCP to prevent disabling it) | #1 |
| High | SCP restricting `ec2:RunInstances` to approved regions/instance types | #4 |
| Medium | Route high-severity alerts to a ticketing/on-call tool, not just email | all |
| Medium | Auto-remediation Lambda: re-apply BPA on `DeleteBucketPublicAccessBlock` | #1 |
| Low | Add CloudTrail data events for sensitive buckets | exfil visibility |

## 7. Evidence integrity
`aws cloudtrail validate-logs` result: `<n valid / n invalid digest files>`
