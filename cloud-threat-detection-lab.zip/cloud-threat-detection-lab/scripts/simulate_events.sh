#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# simulate_events.sh — generates suspicious-but-harmless activity in YOUR OWN
# lab account so every detection in the Terraform stack fires.
#
# Everything created is tagged/prefixed "lab-sim" and recorded in .sim-state
# so scripts/cleanup.sh can remove it. Run cleanup as soon as you've captured
# your evidence.
#
# Usage:  ./simulate_events.sh [--yes] [--skip-ec2]
# Needs:  aws CLI v2, terraform (to read outputs), admin creds for the lab account
# -----------------------------------------------------------------------------
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TF_DIR="${TF_DIR:-$SCRIPT_DIR/../terraform}"
STATE_FILE="$SCRIPT_DIR/.sim-state"

ASSUME_YES=false
SKIP_EC2=false
for arg in "$@"; do
  case "$arg" in
    --yes) ASSUME_YES=true ;;
    --skip-ec2) SKIP_EC2=true ;;
    *) echo "Unknown option: $arg"; exit 1 ;;
  esac
done

log()  { printf '\n\033[1;36m[%s] %s\033[0m\n' "$(date -u +%H:%M:%SZ)" "$*"; }
ok()   { printf '   \033[32m✔ %s\033[0m\n' "$*"; }
warn() { printf '   \033[33m! %s\033[0m\n' "$*"; }
save() { echo "$1=$2" >> "$STATE_FILE"; }

REGION="${AWS_REGION:-$(terraform -chdir="$TF_DIR" output -raw aws_region)}"
DETECTOR_ID="${DETECTOR_ID:-$(terraform -chdir="$TF_DIR" output -raw guardduty_detector_id)}"
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
CALLER_ARN="$(aws sts get-caller-identity --query Arn --output text)"
SUFFIX="$(date +%s)"
PREFIX="lab-sim"

echo "Account : $ACCOUNT_ID"
echo "Caller  : $CALLER_ARN"
echo "Region  : $REGION"
echo "Detector: $DETECTOR_ID"
if ! $ASSUME_YES; then
  read -r -p "This creates intentionally insecure resources in the account above. Type 'yes' to continue: " reply
  [[ "$reply" == "yes" ]] || { echo "Aborted."; exit 1; }
fi

touch "$STATE_FILE"
grep -q '^REGION=' "$STATE_FILE" || save REGION "$REGION"
grep -q '^DETECTOR_ID=' "$STATE_FILE" || save DETECTOR_ID "$DETECTOR_ID"
echo "# run started $(date -u +%FT%TZ)" >> "$STATE_FILE"

# --- 1. GuardDuty sample findings -------------------------------------------
# Validates the EventBridge -> SNS -> email path end-to-end within minutes.
sim_guardduty_samples() {
  log "1/6 Generating high-severity GuardDuty sample findings"
  aws guardduty create-sample-findings --region "$REGION" \
    --detector-id "$DETECTOR_ID" \
    --finding-types \
      'UnauthorizedAccess:IAMUser/InstanceCredentialExfiltration.OutsideAWS' \
      'CryptoCurrency:EC2/BitcoinTool.B!DNS'
  ok "Sample findings created (flagged [SAMPLE] in the console). Expect email in ~5 min."
}

# --- 2. Overly permissive S3 bucket policy -----------------------------------
# MITRE ATT&CK T1530 (Data from Cloud Storage) precursor / misconfiguration.
sim_public_bucket() {
  log "2/6 Creating a bucket and granting anonymous read via bucket policy"
  local bucket="${PREFIX}-public-${ACCOUNT_ID}-${SUFFIX}"
  if [[ "$REGION" == "us-east-1" ]]; then
    aws s3api create-bucket --bucket "$bucket" --region "$REGION" >/dev/null
  else
    aws s3api create-bucket --bucket "$bucket" --region "$REGION" \
      --create-bucket-configuration LocationConstraint="$REGION" >/dev/null
  fi
  save BUCKET "$bucket"
  aws s3api put-bucket-tagging --bucket "$bucket" \
    --tagging 'TagSet=[{Key=Purpose,Value=security-lab-simulation}]'

  aws s3api delete-public-access-block --bucket "$bucket"
  ok "Bucket-level Block Public Access removed (DeleteBucketPublicAccessBlock)"

  local policy
  policy=$(cat <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "LabSimPublicRead",
    "Effect": "Allow",
    "Principal": "*",
    "Action": "s3:GetObject",
    "Resource": "arn:aws:s3:::${bucket}/*"
  }]
}
EOF
)
  if aws s3api put-bucket-policy --bucket "$bucket" --policy "$policy" 2>/dev/null; then
    ok "Public-read bucket policy applied (PutBucketPolicy with Principal \"*\")"
  else
    warn "PutBucketPolicy was denied — account-level Block Public Access is on (good!)."
    warn "The denied call is still in CloudTrail, which is itself worth documenting."
  fi
}

# --- 3. IAM persistence: admin-privileged backdoor user ----------------------
# MITRE ATT&CK T1136.003 (Create Cloud Account) + T1098 (Account Manipulation)
sim_iam_backdoor() {
  log "3/6 Creating an IAM user and attaching AdministratorAccess"
  local user="${PREFIX}-backdoor-${SUFFIX}"
  aws iam create-user --user-name "$user" \
    --tags Key=Purpose,Value=security-lab-simulation >/dev/null
  save IAM_USER "$user"
  aws iam attach-user-policy --user-name "$user" \
    --policy-arn arn:aws:iam::aws:policy/AdministratorAccess
  ok "User $user now has AdministratorAccess (AttachUserPolicy)"
}

# --- 4. Recon with a low-privilege key -> burst of AccessDenied --------------
# MITRE ATT&CK T1580 (Cloud Infrastructure Discovery) with stolen credentials
sim_access_denied() {
  log "4/6 Simulating reconnaissance with a zero-permission access key"
  local user="${PREFIX}-recon-${SUFFIX}"
  aws iam create-user --user-name "$user" \
    --tags Key=Purpose,Value=security-lab-simulation >/dev/null
  save IAM_USER "$user"

  local ak sk
  read -r ak sk < <(aws iam create-access-key --user-name "$user" \
    --query 'AccessKey.[AccessKeyId,SecretAccessKey]' --output text)
  ok "Created key $ak for $user; waiting for IAM propagation"
  sleep 15

  local i
  for i in 1 2 3; do
    for cmd in "s3api list-buckets" "ec2 describe-instances" "iam list-users" \
               "cloudtrail describe-trails" "guardduty list-detectors"; do
      # shellcheck disable=SC2086
      env -u AWS_PROFILE -u AWS_SESSION_TOKEN \
        AWS_ACCESS_KEY_ID="$ak" AWS_SECRET_ACCESS_KEY="$sk" \
        aws $cmd --region "$REGION" >/dev/null 2>&1 || true
    done
  done
  ok "Generated ~15 denied API calls from $ak"
}

# --- 5. Unauthorized EC2 instance that talks to a known-bad domain -----------
# MITRE ATT&CK T1578.002 (Create Cloud Instance) + T1071.004 (DNS C2)
# guarddutyc2activityb.com is an AWS-documented GuardDuty test domain. Looking
# it up from EC2 produces a REAL high-severity Backdoor:EC2/C&CActivity.B!DNS.
sim_rogue_ec2() {
  if $SKIP_EC2; then
    log "5/6 Skipping EC2 simulation (--skip-ec2)"
    return
  fi
  log "5/6 Launching an untagged-by-policy 'rogue' EC2 instance"
  local ami itype user_data iid
  ami=$(aws ssm get-parameter --region "$REGION" \
    --name /aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64 \
    --query Parameter.Value --output text)
  itype="${INSTANCE_TYPE:-t3.micro}"
  user_data='#!/bin/bash
for i in $(seq 1 20); do
  getent hosts guarddutyc2activityb.com || true
  sleep 30
done
shutdown -h now'

  iid=$(aws ec2 run-instances --region "$REGION" \
    --image-id "$ami" --instance-type "$itype" --count 1 \
    --user-data "$user_data" \
    --instance-initiated-shutdown-behavior terminate \
    --metadata-options HttpTokens=required \
    --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=lab-sim-rogue},{Key=Purpose,Value=security-lab-simulation}]' \
    --query 'Instances[0].InstanceId' --output text)
  save INSTANCE "$iid"
  ok "Launched $iid ($itype). It self-terminates after ~10 minutes."
  ok "Expect a real GuardDuty Backdoor:EC2/C&CActivity.B!DNS finding in 5-20 min."
}

# --- 6. Root console login without MFA (manual) ------------------------------
manual_root_login() {
  log "6/6 Manual step: console sign-in without MFA"
  cat <<'EOF'
   Root sign-in can't be scripted. Choose one:

   SAFER (recommended): create a console password for the lab-sim-backdoor user
     aws iam create-login-profile --user-name <lab-sim-backdoor-...> \
       --password '<strong-temp-password>' --password-reset-required
     then sign in at https://<ACCOUNT_ID>.signin.aws.amazon.com/console
     -> fires ConsoleLoginWithoutMFA (cleanup.sh deletes the login profile).

   ROOT (what the brief asks for): only if root has NO MFA yet, sign in as
     root once -> fires RootAccountUsage + ConsoleLoginWithoutMFA.
     Then enable MFA on root immediately. Never disable existing root MFA
     just for this lab.
EOF
}

sim_guardduty_samples
sim_public_bucket
sim_iam_backdoor
sim_access_denied
sim_rogue_ec2
manual_root_login

log "Done. Created resources are listed in $STATE_FILE"
echo "   CloudTrail -> CloudWatch delivery takes ~5-15 min; alarms evaluate every 5 min."
echo "   When you've captured screenshots/queries, run: ./cleanup.sh"
