#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# cleanup.sh — removes everything simulate_events.sh created (from .sim-state)
# and archives GuardDuty sample findings. Safe to re-run.
# -----------------------------------------------------------------------------
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATE_FILE="$SCRIPT_DIR/.sim-state"

[[ -f "$STATE_FILE" ]] || { echo "No $STATE_FILE found — nothing to clean up."; exit 0; }

get()  { grep "^$1=" "$STATE_FILE" | cut -d= -f2-; }
ok()   { printf '   \033[32m✔ %s\033[0m\n' "$*"; }
warn() { printf '   \033[33m! %s\033[0m\n' "$*"; }

REGION="$(get REGION | head -n1)"
DETECTOR_ID="$(get DETECTOR_ID | head -n1)"

echo "== Terminating simulation EC2 instances"
for iid in $(get INSTANCE); do
  aws ec2 terminate-instances --region "$REGION" --instance-ids "$iid" >/dev/null 2>&1 \
    && ok "terminated $iid" || warn "$iid already gone"
done

echo "== Deleting simulation S3 buckets"
for b in $(get BUCKET); do
  aws s3 rb "s3://$b" --force >/dev/null 2>&1 \
    && ok "deleted $b" || warn "$b already gone"
done

echo "== Deleting simulation IAM users"
for u in $(get IAM_USER); do
  aws iam get-user --user-name "$u" >/dev/null 2>&1 || { warn "$u already gone"; continue; }
  for p in $(aws iam list-attached-user-policies --user-name "$u" \
               --query 'AttachedPolicies[].PolicyArn' --output text); do
    aws iam detach-user-policy --user-name "$u" --policy-arn "$p"
  done
  for k in $(aws iam list-access-keys --user-name "$u" \
               --query 'AccessKeyMetadata[].AccessKeyId' --output text); do
    aws iam delete-access-key --user-name "$u" --access-key-id "$k"
  done
  aws iam delete-login-profile --user-name "$u" >/dev/null 2>&1 || true
  aws iam delete-user --user-name "$u" && ok "deleted $u"
done

echo "== Archiving GuardDuty sample findings"
if [[ -n "$DETECTOR_ID" ]]; then
  ids=$(aws guardduty list-findings --region "$REGION" --detector-id "$DETECTOR_ID" \
        --finding-criteria '{"Criterion":{"service.archived":{"Eq":["false"]},"service.additionalInfo.sample":{"Eq":["true"]}}}' \
        --query 'FindingIds' --output text 2>/dev/null)
  if [[ -n "$ids" && "$ids" != "None" ]]; then
    # shellcheck disable=SC2086
    aws guardduty archive-findings --region "$REGION" --detector-id "$DETECTOR_ID" \
      --finding-ids $ids && ok "archived sample findings"
  else
    warn "no unarchived sample findings (or filter unsupported — archive them in the console)"
  fi
fi

mv "$STATE_FILE" "$STATE_FILE.done.$(date +%s)"
echo "Cleanup complete. Real findings are kept for your write-up; archive them when finished."
