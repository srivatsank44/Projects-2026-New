# Cloud Security Logging & Threat Detection Lab (AWS)

Terraform-deployed AWS detection pipeline that captures every API call with CloudTrail,
runs managed threat detection with GuardDuty, and emails high-severity alerts in near
real time. A companion script simulates realistic attacker behavior so each detection
can be verified and documented.

## Architecture

```mermaid
flowchart LR
  subgraph Account["AWS account (all regions)"]
    API[API calls / console sign-ins] --> CT[CloudTrail<br/>multi-region trail]
    EC2[EC2 DNS + VPC traffic] --> GD[GuardDuty]
    CT --> GD
  end
  CT --> S3[(S3 archive<br/>versioned, encrypted,<br/>log-file validation)]
  CT --> CWL[CloudWatch Logs]
  CWL --> MF[8 metric filters<br/>CIS-style detections]
  MF --> AL[CloudWatch alarms]
  GD -->|severity >= 7| EB[EventBridge rule<br/>+ input transformer]
  AL --> SNS[SNS topic]
  EB --> SNS
  SNS --> EMAIL[Email alert]
  CWL --> LI[Logs Insights<br/>investigation queries]
```

**Two detection paths:**
- **Managed:** GuardDuty findings (severity ≥ 7) → EventBridge → SNS → email, reformatted into a readable alert.
- **Custom:** CloudTrail → CloudWatch Logs → metric filters → alarms → SNS for root usage, MFA-less logins, S3 policy changes, IAM privilege changes, AccessDenied bursts, EC2 launches, and CloudTrail/GuardDuty tampering.

## Repository layout
```
terraform/     IaC for the whole lab (versions, cloudtrail, guardduty, alerting, outputs)
scripts/       simulate_events.sh (attack simulation) and cleanup.sh
queries/       CloudWatch Logs Insights hunting queries
docs/          audit-analysis-report.md (fill in after your run) + screenshots/
```

## Cost & safety notes
- Use a **dedicated lab account**, never a work or production account.
- CloudTrail: the first copy of management events is free. If the account already has a trail, this one is billed as a second copy (~$2 per 100k events; a lab generates far fewer).
- GuardDuty: 30-day free trial per region. **Destroy the stack after the trial** or it starts billing.
- CloudWatch: 8 alarms fit within the 10-alarm free tier; log ingestion for a lab stays well under the 5 GB free allowance.
- The EC2 simulation launches one micro instance that self-terminates after ~10 minutes. Set `INSTANCE_TYPE=t2.micro` if that's your account's free-tier type, or pass `--skip-ec2`.
- Set a **billing alarm / AWS Budget** before starting.

## Deploy
Prerequisites: Terraform ≥ 1.5, AWS CLI v2, credentials for the lab account.

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars   # set alert_email
terraform init
terraform plan -out tfplan
terraform apply tfplan
```
Then **click the confirmation link in the SNS email** — no alerts are delivered until you do.

> If GuardDuty is already enabled in the region, import the detector first:
> `terraform import aws_guardduty_detector.main $(aws guardduty list-detectors --query 'DetectorIds[0]' --output text)`

## Simulate attacks
```bash
cd scripts
chmod +x simulate_events.sh cleanup.sh
./simulate_events.sh
```

| Step | Behavior | Expected alert |
|---|---|---|
| 1 | GuardDuty sample findings | Email within ~5 min (tests the pipeline) |
| 2 | Bucket with Block Public Access removed + `Principal: "*"` policy | `S3BucketPolicyChanges` alarm, GuardDuty S3 policy finding |
| 3 | IAM user with `AdministratorAccess` | `IAMPolicyChanges` alarm |
| 4 | Zero-permission key enumerating services | `UnauthorizedAPICalls` alarm |
| 5 | Rogue EC2 instance resolving an AWS GuardDuty test domain | `EC2InstanceLaunched` alarm + **real** `Backdoor:EC2/C&CActivity.B!DNS` email |
| 6 | Console login without MFA (manual; instructions printed) | `ConsoleLoginWithoutMFA` / `RootAccountUsage` |

Expect 5–20 minutes of delivery latency. If account-level S3 Block Public Access is on,
step 2's policy call is denied. That is the correct secure outcome, and the denied call is still logged.

## Analyze
1. Open **CloudWatch → Logs Insights**, select the trail's log group, and run the queries in `queries/logs-insights-queries.md`.
2. Open **GuardDuty → Findings** and review the real (non-sample) findings.
3. Complete `docs/audit-analysis-report.md`: coverage matrix, attacker timeline, evidence, MTTD, gaps and hardening recommendations. Redact account IDs, key IDs and IPs.
4. Run `aws cloudtrail validate-logs` to show the evidence wasn't tampered with.

## Tear down
```bash
./scripts/cleanup.sh
cd terraform && terraform destroy
```

## Ideas for extending it
- Auto-remediation Lambda that re-enables Block Public Access when it's removed.
- Security Hub with the CIS AWS Foundations standard for posture scoring.
- Athena table over the S3 archive for SQL-based hunting.
- Slack or PagerDuty delivery via AWS Chatbot or a Lambda subscriber.
- CI pipeline running `terraform validate`, `tflint` and `checkov`.
