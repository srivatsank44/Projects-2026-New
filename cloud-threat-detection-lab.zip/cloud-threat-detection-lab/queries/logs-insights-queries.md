# CloudWatch Logs Insights — CloudTrail Investigation Queries

Run these in **CloudWatch → Logs Insights** against the log group
`/aws/cloudtrail/cloud-threat-lab-trail`. Set the time range to cover your simulation window.
Save each as a query definition and screenshot the results for your write-up.

## 1. Root account activity
```
fields @timestamp, eventName, eventSource, sourceIPAddress, userAgent, additionalEventData.MFAUsed
| filter userIdentity.type = "Root"
| sort @timestamp desc
```

## 2. Console sign-ins and MFA status
```
fields @timestamp, userIdentity.type, userIdentity.arn, sourceIPAddress,
       additionalEventData.MFAUsed as mfa, responseElements.ConsoleLogin as result
| filter eventName = "ConsoleLogin"
| sort @timestamp desc
```

## 3. S3 exposure changes (who opened what, and how)
```
fields @timestamp, userIdentity.arn, eventName, requestParameters.bucketName as bucket,
       errorCode, sourceIPAddress
| filter eventSource = "s3.amazonaws.com"
  and eventName in ["PutBucketPolicy","DeleteBucketPublicAccessBlock","PutBucketPublicAccessBlock","PutBucketAcl","DeleteBucketPolicy"]
| sort @timestamp desc
```
To read the exact policy that was applied, expand `requestParameters.bucketPolicy` on the matching event.

## 4. IAM persistence: new users, keys and privilege grants
```
fields @timestamp, userIdentity.arn as actor, eventName,
       requestParameters.userName as target_user, requestParameters.policyArn as policy
| filter eventSource = "iam.amazonaws.com"
  and eventName in ["CreateUser","CreateAccessKey","AttachUserPolicy","PutUserPolicy","CreateLoginProfile","AddUserToGroup"]
| sort @timestamp asc
```

## 5. Access-denied bursts by principal (recon / stolen-key signal)
```
filter errorCode like /AccessDenied|UnauthorizedOperation/
| stats count(*) as denied, count_distinct(eventName) as distinct_apis,
        earliest(@timestamp) as first_seen, latest(@timestamp) as last_seen
  by userIdentity.arn, userIdentity.accessKeyId, sourceIPAddress
| sort denied desc
```
Many *distinct* APIs failing from one key in a short window is the classic enumeration pattern.

## 6. EC2 launches (unauthorized compute)
```
fields @timestamp, awsRegion, userIdentity.arn, requestParameters.instanceType as type,
       responseElements.instancesSet.items.0.instanceId as instance_id, sourceIPAddress
| filter eventName = "RunInstances"
| sort @timestamp desc
```

## 7. Defense evasion — logging/detection tampering
```
fields @timestamp, userIdentity.arn, eventSource, eventName, errorCode
| filter eventName in ["StopLogging","DeleteTrail","UpdateTrail","PutEventSelectors",
                       "DeleteDetector","UpdateDetector","CreateFilter","DeleteFlowLogs"]
| sort @timestamp desc
```

## 8. Full timeline for one actor (pivot query)
Replace the ARN or access key with the one you're investigating.
```
fields @timestamp, eventSource, eventName, awsRegion, sourceIPAddress, errorCode
| filter userIdentity.arn like /lab-sim-backdoor/ or userIdentity.accessKeyId = "AKIA..."
| sort @timestamp asc
```

## 9. Activity outside your home region
```
filter awsRegion != "us-east-1" and eventSource != "sts.amazonaws.com"
| stats count(*) by awsRegion, eventName, userIdentity.arn
| sort count(*) desc
```

## Integrity check (evidence handling)
CloudTrail log file validation is enabled, so you can prove the S3 archive wasn't altered:
```bash
aws cloudtrail validate-logs \
  --trail-arn arn:aws:cloudtrail:us-east-1:<ACCOUNT_ID>:trail/cloud-threat-lab-trail \
  --start-time 2026-09-25T00:00:00Z
```
