# Endpoint Threat Hunting & Memory Forensics (DFIR Lab)

A controlled digital-forensics and incident-response (DFIR) project. I built an
isolated lab, simulated a Windows endpoint compromise, acquired and analyzed
memory and disk evidence, correlated the findings, and produced a full DFIR
report.

> **Lab exercise, not a real incident.** All activity was generated with the
> [Atomic Red Team](https://github.com/redcanaryco/atomic-red-team) framework on
> a personal, isolated virtual machine. No real victim, client, or production
> data is involved. Hostname and usernames are throwaway lab values.

---

## What this project demonstrates

- Live **memory acquisition** with FTK Imager (RAM + pagefile)
- **Memory forensics** with Volatility 3 (process tree, injected code, registry,
  network, command lines)
- **Endpoint artifact collection** with KAPE and parsing with Eric Zimmerman tools
- **Correlation** of memory findings with on-disk and event-log evidence
- A professional **DFIR report** with IOCs, an ATT&CK mapping, remediation, and
  threat-hunting guidance

## Lab setup

| VM | Role | Notes |
| --- | --- | --- |
| Victim (Windows 11 Enterprise) | Compromised host | Sysmon + PowerShell Script Block Logging + command-line auditing enabled before the attack |
| Attacker (Kali Linux) | Attack staging | On an isolated internal network |
| Analyst | Analysis workstation | Volatility 3, KAPE, EZ tools |

All VMs ran on VirtualBox on an **isolated internal network** (no internet),
so nothing could escape the lab.

## Attack scenario (MITRE ATT&CK)

| Technique | ID | What it did |
| --- | --- | --- |
| Command and Scripting Interpreter: PowerShell | T1059.001 | Ran a PowerShell command |
| Boot or Logon Autostart: Registry Run Keys | T1547.001 | Added a Run-key autostart entry |
| Scheduled Task/Job | T1053.005 | Created two scheduled tasks (one as SYSTEM) |
| Process Injection | T1055 | Injected shellcode into `calc.exe` |

## Tools

Volatility 3 · KAPE · FTK Imager · Eric Zimmerman tools (EvtxECmd, RECmd, PECmd,
MFTECmd, AmcacheParser) · Sysmon · Atomic Red Team

## Key findings

All four techniques were confirmed, most corroborated across **both** memory and
disk/event-log sources:

1. **Process injection (T1055)** — process tree showed `CreateThread.exe` (from an
   anomalous path) spawning `calc.exe`; PowerShell 4104 logs captured the exact
   command.
2. **Run-key persistence (T1547.001)** — recovered the malicious `Atomic Red Team`
   Run value directly from the `ntuser.dat` hive in memory.
3. **Scheduled-task persistence (T1053.005)** — Sysmon Event ID 1 captured the full
   `schtasks /create` command, including a task running as SYSTEM.
4. **PowerShell execution (T1059.001)** — Event ID 4104 captured the script block;
   memory showed an executable (RWX) region in `powershell.exe`.

A central lesson of the project: memory preserves the live/transient state, while
disk and event logs preserve the persistent and historical record. Correlating
the two is what reconstructs the full incident.

## Repository contents

```
report/        Full DFIR investigation report (PDF)
iocs/          Indicators of compromise (CSV)
docs/          Commands cheat sheet, lab diagram
detections/    Sigma / YARA rules (optional)
screenshots/   Sanitized analysis screenshots
```

> Raw evidence (memory dump, pagefile, payloads, full logs) is intentionally
> **not** included: it is large and should not be redistributed.

## How to read the report

Start with `report/DFIR-Report.pdf`. It covers the executive summary, methodology
and chain of custody, the attack timeline, technical findings, root cause, IOCs,
ATT&CK mapping, remediation, and threat-hunting insights.
