# Case Study 1: Fake "Microsoft Unusual Sign-in" Callback Phish

**Sample:** `sample-10.eml` from the public [phishing_pot](https://github.com/rf-peixoto/phishing_pot) honeypot collection
**Received:** 8 September 2023, delivered via Microsoft 365
**Verdict:** 🔴 MALICIOUS. Scored 76/100 before the parser fixes described below and [YOUR NEW SCORE]/100 after.

---

## Summary

The email impersonates the Microsoft account security team and claims someone signed in to the
victim's account from Moscow, Russia. Instead of a credential-harvesting link, every button
("Report The User", "click here") opens a `mailto:` link to a **Gmail address**
(`sotrecognizd@gmail[.]com`). This is a **reply-based (callback) phish**: the attacker wants the
panicked victim to email them, which starts a conversation that typically leads to a fake
"support" call, remote-access software or a request for account details.

## Key Evidence

**Sender spoofing.** The display name says "Microsoft account team", but the real sending domain is
`access-accsecurity[.]com`, which is not a Microsoft domain. The From header was also
**deliberately malformed** (`Microsoft account team ,_<no-reply@...>`). Standard parsers,
including the first version of my tool, could not read it. This is a known trick to confuse
spam filters and mail clients.

**Authentication.**

| Check | Result | Meaning |
|---|---|---|
| SPF | `none` | The envelope domain `thcultarfdes[.]co[.]uk` publishes no SPF record |
| DKIM | `none` | The message was not signed at all |
| DMARC | `permerror` | The From domain's DMARC record is broken, so it offers no protection |
| Alignment | ❌ | No authenticated domain matches the From domain |

Three different domains are involved: From (`access-accsecurity[.]com`), envelope sender
(`thcultarfdes[.]co[.]uk`) and Reply-To (Gmail). Legitimate Microsoft mail passes SPF, DKIM
and DMARC for `microsoft.com`.

**Reply-To diversion.** Replies go to a free Gmail account instead of the sender, a classic sign
that the attacker wants to receive responses somewhere disposable.

**Filter evasion.** Below the visible message, the HTML hides hundreds of random words in many
languages ("maldives, wuhan, countertop, acupuncture..."). This "hash-busting" or
Bayesian-poisoning technique makes each copy look unique and dilutes the phishing keywords that
spam filters score.

**Fake urgency.** Country (Russia), a specific IP and a timestamp just seconds before delivery make
the alert feel real and immediate.

## Attacker Infrastructure

| Indicator | Type | Role | Reputation |
|---|---|---|---|
| `89[.]144[.]44[.]2` | IP | Originating mail server (recorded by Microsoft 365) | VT: [X/Y] · AbuseIPDB: [Z%] |
| `thebandalisty[.]com` | Domain | Hidden tracking pixel (confirms the victim opened the email) | VT: [X/Y] |
| `access-accsecurity[.]com` | Domain | Spoofed From domain | Not enriched (see lessons learned) |
| `thcultarfdes[.]co[.]uk` | Domain | Envelope sender / bounce domain | Not enriched |
| `sotrecognizd@gmail[.]com` | Email | Attacker's reply inbox | n/a |

`103[.]225[.]77[.]255` appears in the body, but it is part of the **lure text** (the "suspicious
sign-in IP" shown to the victim), not attacker mail infrastructure. It shouldn't be blocked based
on this email alone.

## Response Actions

1. Search all mailboxes for messages from `access-accsecurity[.]com` or with Reply-To
   `sotrecognizd@gmail[.]com`, and remove them.
2. Block the sender and envelope domains at the email gateway, and add a rule that flags
   "Microsoft" in the display name when the sending domain isn't Microsoft's.
3. **Search sent mail for replies to the Gmail address.** Anyone who replied is now in contact with
   the attacker and should be contacted by the security team directly.
4. Remind users that Microsoft never asks them to report sign-ins by emailing a Gmail address, and
   that real alerts can be checked by signing in at account.microsoft.com directly.

## Lessons Learned

**The first version of the tool under-scored this email.** Header and content evidence totalled only
16/100, and the MALICIOUS verdict came almost entirely from threat-intel reputation. Investigating
why revealed two parser bugs:

1. **Malformed From header.** Python's `parseaddr()` returned nothing, so the sender domain was blank
   and the brand-impersonation check never ran. I added a fallback parser that recovers the address
   and flags the malformation itself as suspicious.
2. **Microsoft 365 Authentication-Results format.** Microsoft omits the authserv-id that RFC 8601
   places first, so the parser skipped the SPF result. It also treated `dmarc=permerror` as
   harmless. I fixed both and added support for Microsoft's `compauth=fail` verdict.

After the fixes, header evidence alone rose from **16 to 41**, so the tool now flags this email as
SUSPICIOUS even with no threat intel. I added regression tests for both bugs (19 tests total).

**Remaining gaps I identified:**

- The tool ignores `mailto:` links, yet in this campaign they *are* the payload. A future version should
  treat replies directed to free-mail addresses as a strong callback-phishing signal.
- Spoofed From and envelope domains are analysed but not sent for reputation lookups.
- The hidden word salad isn't detected yet; hidden-text ratio would be a useful content feature.

**Wider test results:** I ran the tool on three phishing_pot samples. Two scored LOW RISK in the first
version. After the fixes, the Bradesco bank impersonation (`sample-1`) rose to SUSPICIOUS on
header evidence alone. The third (`sample-100`) is unsolicited solar-panel marketing: spam, but
not credential phishing, so a lower score is arguably correct. This showed me that "phishing
datasets" need careful labelling before they're used to judge a detector.
