# Phishing Triage Report — PT-20260927-59049247

| Field | Value |
|---|---|
| Generated | 2026-09-27 00:01:11Z |
| Tool | phishtriage v1.0.0 (live) |
| Source file | `benign_newsletter.eml` |
| Message SHA256 | `59049247598f72317c6855b0085376eef4bcff5638c6cb75803bf0653dead26c` |

## 1. Verdict: 🟢 **LOW RISK** — risk score 0/100

Score composition: header/authentication **0**/45 · content **0**/30 · threat intel **0**/60 (0.6 × worst IOC score), capped at 100.

**Key evidence:**


## 2. Message Summary

| Header | Value |
|---|---|
| Subject | Your September trail report is here |
| Date | Mon, 14 Sep 2026 14:00:03 +0000 |
| To | j.doe@acmecorp.example |
| From (display) | Contoso Outdoors |
| From (address) | news@mail.contoso-outdoors.example |
| Reply-To | — |
| Return-Path | b@bounces.contoso-outdoors.example |
| Message-ID | <a81c2f.20260914140003@mail.contoso-outdoors.example> |
| X-Mailer | — |

## 3. Authentication & Alignment

Parsed from: Authentication-Results (topmost). Alignment is **recomputed locally** (DMARC relaxed mode, organisational-domain match against From domain `mail.contoso-outdoors.example`) rather than trusting the gateway verdict.

| Mechanism | Result | Authenticated domain | Aligned with From? |
|---|---|---|---|
| SPF | `pass` | bounces.contoso-outdoors.example | ✅ yes |
| DKIM | `pass` | contoso-outdoors.example (s=k1) | ✅ yes |
| DMARC (reported) | `pass` (p=quarantine) | mail.contoso-outdoors.example | — |
| DMARC (recomputed) | `pass` | — | SPF or DKIM aligned = pass |

## 4. Delivery Path (oldest → newest)

| # | From (HELO) | From IP | Received by | Protocol | Timestamp | Δ |
|---|---|---|---|---|---|---|
| 1 | out-40.contoso-outdoors.example | `192.0.2.40` 🌐 | mx-gw01.acmecorp.example | ESMTPS | 2026-09-14T10:00:05-04:00 | — |
| 2 | mx-gw01.acmecorp.example | `10.20.1.15` | mbx02.acmecorp.example | Microsoft SMTP Server | 2026-09-14T10:00:06-04:00 | +1s |

**Originating IP:** `192.0.2.40` — source: Received-SPF client-ip (recorded by receiving MTA)  
🌐 = externally routable. All external hop IPs were extracted as IOCs: `192.0.2.40`

## 5. Findings

| Severity | Code | Points | Description | ATT&CK |
|---|---|---|---|---|
| INFO | `CONTAINS_LINKS` | 0 | 2 non-allowlisted URL(s) present. | T1566.002 |

## 6. Indicators of Compromise & Enrichment

Indicators are defanged. Score = worst provider score (0-100). Provider columns: VirusTotal / AbuseIPDB / Hybrid Analysis.

| Type | Indicator | Found in | VirusTotal | AbuseIPDB | Hybrid Analysis | Score | Verdict |
|---|---|---|---|---|---|---|---|
| url | `hxxps://www[.]contoso-outdoors[.]example/trails/september` | body:text | not found | n/a | n/a | — | **unknown** |
| url | `hxxps://www[.]contoso-outdoors[.]example/unsubscribe` | body:text | not found | n/a | n/a | — | **unknown** |
| domain | `www[.]contoso-outdoors[.]example` | body:text | error | n/a | n/a | — | **unknown** |
| ip | `192[.]0[.]2[.]40` | header:originating | 0/91 malicious | 0% confidence, 5 reports | n/a | 0 | **clean** |

## 7. Attachments

No attachments.

## 8. MITRE ATT&CK Mapping

| Technique | Name | Evidence |
|---|---|---|
| T1566.002 | Phishing: Spearphishing Link | `CONTAINS_LINKS` |

## 9. Recommended Response Actions

1. No automated containment required. Release if quarantined and close as benign/spam after analyst spot-check.
2. If user-reported, thank the reporter and tune gateway rules if this was bulk/marketing mail.

## 10. Analyst Notes & Limitations

- Authentication results are taken from the **topmost** Authentication-Results header (added by the receiving gateway); lower headers are attacker-controllable and ignored.
- Received hops below the organisation's boundary MTA can be forged; the originating IP is chosen from the most trustworthy available source (see section 4).
- 'Not found' in a reputation service is **not** evidence of safety — freshly registered phishing infrastructure frequently has no history.
- Automated verdicts support, not replace, analyst judgement. Confirm before tenant-wide purge.
