"""Build samples/m365_credential_phish.eml - a SYNTHETIC, SAFE training sample.

It reproduces the header structure of a real-world Microsoft 365 credential-harvesting
campaign, but every piece of attacker infrastructure uses reserved names/addresses:
  * domains under the reserved .test TLD (RFC 2606) - cannot resolve
  * IPs from RFC 5737 documentation ranges (192.0.2/24, 198.51.100/24, 203.0.113/24)
  * the HTML attachment contains no form, script or payload
Run: python scripts/build_sample.py
"""
from email.message import EmailMessage
from email import policy
from pathlib import Path

PHISH_URL = "https://login.micros0ft-365-verify.test/owa/auth.php?u=j.doe@acmecorp.example&sid=8841"
PIXEL_URL = "http://198.51.100.23/track/open.gif?id=jdoe-8841"

msg = EmailMessage(policy=policy.SMTP)
msg["From"] = '"Microsoft 365 Security" <no-reply@microsoft.com>'
msg["To"] = "John Doe <j.doe@acmecorp.example>"
msg["Reply-To"] = "account-review@secure-notify-portal.test"
msg["Subject"] = "[Action Required] Unusual sign-in activity detected on your account"
msg["Date"] = "Tue, 15 Sep 2026 12:42:14 +0000"
msg["Message-ID"] = "<20260915124214.8841.4471@secure-notify-portal.test>"
msg["X-Mailer"] = "PHPMailer 6.8.0 (https://github.com/PHPMailer/PHPMailer)"

msg.set_content(f"""Microsoft 365 Security Alert

We detected an unusual sign-in attempt on your account j.doe@acmecorp.example
Location: Lagos, Nigeria   IP: 102.89.x.x   Time: 15 Sep 2026 11:58 UTC

If this wasn't you, secure your account within 24 hours to avoid suspension:
{PHISH_URL}

Microsoft Account Team
""")
msg.add_alternative(f"""<html><body style="font-family:Segoe UI,Arial">
<h2 style="color:#0078d4">Unusual sign-in activity</h2>
<p>We detected an unusual sign-in attempt on your account <b>j.doe@acmecorp.example</b>.</p>
<p>If this wasn't you, review your activity within <b>24 hours</b> to avoid suspension:</p>
<p><a href="{PHISH_URL}">https://account.microsoft.com/security</a></p>
<p style="color:#666;font-size:11px">Microsoft Corporation, One Microsoft Way, Redmond, WA</p>
<img src="{PIXEL_URL}" width="1" height="1" alt="">
</body></html>""", subtype="html")
msg.add_attachment(
    b"<!DOCTYPE html>\n<html><head><title>Secure Document Viewer</title></head>\n"
    b"<body><!-- SYNTHETIC TRAINING SAMPLE: credential-harvesting form intentionally removed --></body></html>\n",
    maintype="text", subtype="html", filename="Security_Review_Sept.pdf.html",
)

trace = """Received: from mx-gw01.acmecorp.example (10.20.1.15) by mbx02.acmecorp.example
 (10.20.1.40) with Microsoft SMTP Server (version=TLS1_2) id 15.2.1544.4;
 Tue, 15 Sep 2026 08:42:19 -0400
Authentication-Results: mx-gw01.acmecorp.example;
 spf=pass (sender IP is 203.0.113.77) smtp.mailfrom=bounce-8841@secure-notify-portal.test;
 dkim=pass (2048-bit key) header.d=secure-notify-portal.test header.s=s1;
 dmarc=fail (p=reject dis=quarantine) header.from=microsoft.com
Received-SPF: Pass (mx-gw01.acmecorp.example: domain of bounce-8841@secure-notify-portal.test
 designates 203.0.113.77 as permitted sender) client-ip=203.0.113.77;
 envelope-from=<bounce-8841@secure-notify-portal.test>; helo=mail.secure-notify-portal.test;
Received: from mail.secure-notify-portal.test (unknown [203.0.113.77])
 by mx-gw01.acmecorp.example (Postfix) with ESMTPS id 4F2A1C03B7
 for <j.doe@acmecorp.example>; Tue, 15 Sep 2026 08:42:17 -0400 (EDT)
Received: from [192.168.1.23] (unknown [198.51.100.14])
 by mail.secure-notify-portal.test (Postfix) with ESMTPSA id 88A1E2F04
 for <j.doe@acmecorp.example>; Tue, 15 Sep 2026 12:42:15 +0000 (UTC)
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=secure-notify-portal.test;
 s=s1; t=1789476135; h=from:to:subject:date:message-id:reply-to;
 bh=SYNTHETICbodyhashAAAAAAAAAAAAAAAAAAAAAAAAAAA=;
 b=SYNTHETICsignatureAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
Return-Path: <bounce-8841@secure-notify-portal.test>
"""
out = Path(__file__).resolve().parents[1] / "samples" / "m365_credential_phish.eml"
out.write_bytes(trace.replace("\n", "\r\n").encode() + msg.as_bytes())
print(f"wrote {out}")


# ---------------------------------------------------------------- benign control sample
ok = EmailMessage(policy=policy.SMTP)
ok["From"] = '"Contoso Outdoors" <news@mail.contoso-outdoors.example>'
ok["To"] = "j.doe@acmecorp.example"
ok["Subject"] = "Your September trail report is here"
ok["Date"] = "Mon, 14 Sep 2026 14:00:03 +0000"
ok["Message-ID"] = "<a81c2f.20260914140003@mail.contoso-outdoors.example>"
ok.set_content("Hi John,\n\nThis month's trail report: https://www.contoso-outdoors.example/trails/september\n\nUnsubscribe: https://www.contoso-outdoors.example/unsubscribe\n")
ok_trace = """Received: from mx-gw01.acmecorp.example (10.20.1.15) by mbx02.acmecorp.example
 (10.20.1.40) with Microsoft SMTP Server (version=TLS1_2) id 15.2.1544.4;
 Mon, 14 Sep 2026 10:00:06 -0400
Authentication-Results: mx-gw01.acmecorp.example;
 spf=pass (sender IP is 192.0.2.40) smtp.mailfrom=bounces.contoso-outdoors.example;
 dkim=pass (2048-bit key) header.d=contoso-outdoors.example header.s=k1;
 dmarc=pass (p=quarantine) header.from=mail.contoso-outdoors.example
Received-SPF: Pass (mx-gw01.acmecorp.example: domain of b@bounces.contoso-outdoors.example
 designates 192.0.2.40 as permitted sender) client-ip=192.0.2.40;
Received: from out-40.contoso-outdoors.example (out-40.contoso-outdoors.example [192.0.2.40])
 by mx-gw01.acmecorp.example (Postfix) with ESMTPS id 91B2D0A1C4
 for <j.doe@acmecorp.example>; Mon, 14 Sep 2026 10:00:05 -0400 (EDT)
Return-Path: <b@bounces.contoso-outdoors.example>
"""
out2 = out.parent / "benign_newsletter.eml"
out2.write_bytes(ok_trace.replace("\n", "\r\n").encode() + ok.as_bytes())
print(f"wrote {out2}")
