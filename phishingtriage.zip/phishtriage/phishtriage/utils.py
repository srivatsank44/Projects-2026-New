"""Shared helpers: domain normalisation, defang/refang, IP classification, findings."""
from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from email.utils import parseaddr
from urllib.parse import urlsplit, urlunsplit

try:  # Optional: accurate Public Suffix List handling. Uses bundled snapshot, no network.
    import tldextract

    _EXTRACT = tldextract.TLDExtract(suffix_list_urls=())
except Exception:  # pragma: no cover - optional dependency
    _EXTRACT = None

# Fallback for the most common multi-label public suffixes when tldextract is absent.
_MULTI_LABEL_SUFFIXES = {
    "co.uk", "org.uk", "ac.uk", "gov.uk", "com.au", "net.au", "org.au", "co.jp",
    "co.nz", "co.za", "com.br", "com.mx", "co.in", "com.sg", "com.tr", "com.cn",
}

# Networks that are *never* an attacker's public origin. Deliberately narrower than
# ipaddress.is_private, which also treats RFC 5737 documentation ranges as private.
_INTERNAL_NETS = [ipaddress.ip_network(n) for n in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8",
    "169.254.0.0/16", "100.64.0.0/10", "0.0.0.0/8",
    "::1/128", "fc00::/7", "fe80::/10",
)]

SEVERITY_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


@dataclass
class Finding:
    """A single analyst-readable observation that contributes to the risk score."""
    code: str
    severity: str
    description: str
    points: int = 0
    attack: str | None = None  # MITRE ATT&CK technique ID


def is_valid_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def is_internal_ip(value: str) -> bool:
    try:
        addr = ipaddress.ip_address(value)
    except ValueError:
        return True
    return any(addr in net for net in _INTERNAL_NETS if net.version == addr.version)


def domain_of(address: str | None) -> str:
    """Return the lowercase domain part of an email address (or bare domain)."""
    if not address:
        return ""
    addr = parseaddr(address)[1] or address
    addr = addr.strip().strip("<>").lower()
    return addr.rsplit("@", 1)[-1] if "@" in addr else addr


def org_domain(domain: str | None) -> str:
    """Organisational domain (registrable domain), as used for DMARC relaxed alignment."""
    if not domain:
        return ""
    d = domain.lower().strip().strip(".<>")
    if _EXTRACT is not None:
        try:
            ext = _EXTRACT(d)
            if ext.domain and ext.suffix:
                return f"{ext.domain}.{ext.suffix}"
        except Exception:
            pass
    parts = d.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in _MULTI_LABEL_SUFFIXES:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def refang(text: str) -> str:
    """Undo common defanging so IOCs shared by analysts/threat intel can be parsed."""
    t = re.sub(r"hxxp", "http", text, flags=re.I)
    t = re.sub(r"\[\s*\.\s*\]|\(\s*\.\s*\)|\{\s*\.\s*\}|\[dot\]|\(dot\)", ".", t, flags=re.I)
    t = t.replace("[:]", ":").replace("[://]", "://")
    return t


def defang(value: str) -> str:
    """Make an indicator non-clickable for reports (hxxp + [.] in the host only)."""
    if re.match(r"^(https?|ftp)://", value, re.I):
        parts = urlsplit(value)
        scheme = parts.scheme.replace("http", "hxxp").replace("ftp", "fxp")
        return urlunsplit((scheme, parts.netloc.replace(".", "[.]"), parts.path, parts.query, parts.fragment))
    return value.replace(".", "[.]")


# Brand keyword -> legitimate organisational domains.
BRANDS: dict[str, set[str]] = {
    "microsoft": {"microsoft.com", "office.com", "office365.com", "microsoftonline.com", "live.com", "outlook.com", "sharepoint.com"},
    "office365": {"microsoft.com", "office.com", "office365.com", "microsoftonline.com"},
    "outlook": {"microsoft.com", "outlook.com", "live.com"},
    "paypal": {"paypal.com"},
    "docusign": {"docusign.com", "docusign.net"},
    "apple": {"apple.com", "icloud.com"},
    "icloud": {"apple.com", "icloud.com"},
    "amazon": {"amazon.com", "amazonses.com"},
    "google": {"google.com", "gmail.com", "googlemail.com"},
    "netflix": {"netflix.com"},
    "dropbox": {"dropbox.com"},
    "adobe": {"adobe.com"},
    "wellsfargo": {"wellsfargo.com"},
    "fedex": {"fedex.com"},
}

_HOMOGLYPHS = str.maketrans({"0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t", "$": "s", "@": "a"})


def normalise_lookalike(text: str) -> str:
    t = text.lower().translate(_HOMOGLYPHS).replace("rn", "m").replace("vv", "w")
    return re.sub(r"[^a-z]", "", t)


def lookalike_brand(domain: str | None) -> str | None:
    """Return the brand a domain appears to imitate, or None if legitimate/unrelated."""
    if not domain:
        return None
    od = org_domain(domain)
    host_norm = normalise_lookalike(domain)
    for brand, legit in BRANDS.items():
        if od in legit:
            return None
        if brand in host_norm:
            return brand
    return None


def brand_in_text(text: str | None) -> str | None:
    if not text:
        return None
    norm = normalise_lookalike(text)
    for brand in BRANDS:
        if brand in norm:
            return brand
    return None
