"""Extract indicators of compromise from message bodies, headers and attachments."""
from __future__ import annotations

import hashlib
import io
import mimetypes
import re
import zipfile
from dataclasses import asdict, dataclass, field
from email.message import EmailMessage
from html.parser import HTMLParser
from urllib.parse import parse_qs, urlsplit

from .header_parser import HeaderReport
from .utils import Finding, is_internal_ip, is_valid_ip, lookalike_brand, org_domain, refang

URL_RE = re.compile(r"\b(?:https?|ftp)://[^\s<>\"'`{}|\\^\[\]]+", re.I)
IPV4_RE = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")
LOOKS_LIKE_URL = re.compile(r"^(?:https?://)?(?:[\w-]+\.)+[a-z]{2,}(?:[/:?#]\S*)?$", re.I)

# Domains that appear in almost every HTML email and are not worth enrichment quota.
DEFAULT_ALLOWLIST = {
    "w3.org", "schemas.microsoft.com", "microsoft.com", "office.com", "google.com",
    "gstatic.com", "googleapis.com", "apple.com", "outlook.com", "live.com",
}
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "rb.gy", "cutt.ly", "ow.ly", "buff.ly", "shorturl.at", "t.ly"}

RISKY_EXT = {
    ".exe", ".scr", ".com", ".pif", ".js", ".jse", ".vbs", ".vbe", ".wsf", ".hta", ".html", ".htm",
    ".shtml", ".svg", ".iso", ".img", ".vhd", ".lnk", ".one", ".bat", ".cmd", ".ps1", ".msi", ".jar",
    ".docm", ".xlsm", ".pptm", ".xlam", ".dotm", ".xll", ".cab", ".ace", ".r00",
}
MACRO_EXT = {".docm", ".xlsm", ".pptm", ".xlam", ".dotm"}
LURE_EXT = {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png", ".txt", ".csv", ".rtf"}
EXPECTED_MAGIC = {
    ".pdf": "PDF", ".docx": "ZIP/OOXML", ".xlsx": "ZIP/OOXML", ".pptx": "ZIP/OOXML", ".zip": "ZIP/OOXML",
    ".doc": "OLE2", ".xls": "OLE2", ".ppt": "OLE2", ".msi": "OLE2", ".exe": "PE executable",
    ".rar": "RAR", ".7z": "7-Zip", ".rtf": "RTF", ".png": "PNG", ".jpg": "JPEG", ".jpeg": "JPEG",
    ".html": "HTML", ".htm": "HTML",
}
_MAGIC = [
    (b"MZ", "PE executable"), (b"PK\x03\x04", "ZIP/OOXML"), (b"%PDF", "PDF"),
    (b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "OLE2"), (b"Rar!", "RAR"), (b"7z\xbc\xaf\x27\x1c", "7-Zip"),
    (b"{\\rtf", "RTF"), (b"\x89PNG", "PNG"), (b"\xff\xd8\xff", "JPEG"), (b"L\x00\x00\x00\x01\x14\x02\x00", "Windows shortcut (LNK)"),
]


@dataclass
class IOC:
    type: str      # url | domain | ip | hash
    value: str
    source: str    # where it was found
    skip_enrichment: bool = False
    note: str = ""


@dataclass
class Attachment:
    filename: str
    declared_type: str
    detected_type: str
    size: int
    md5: str
    sha1: str
    sha256: str
    flags: list[str] = field(default_factory=list)


@dataclass
class IOCReport:
    iocs: list[IOC]
    attachments: list[Attachment]
    findings: list[Finding]

    def by_type(self, t: str) -> list[IOC]:
        return [i for i in self.iocs if i.type == t]

    def to_dict(self) -> dict:
        return asdict(self)


class _LinkParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links: list[str] = []
        self.anchors: list[tuple[str, str]] = []
        self.forms: list[str] = []
        self._href: str | None = None
        self._text: list[str] = []

    def handle_starttag(self, tag, attrs):
        a = {k.lower(): (v or "") for k, v in attrs}
        for attr in ("href", "src", "action", "background", "data-src"):
            if a.get(attr):
                self.links.append(a[attr].strip())
        if tag == "form":
            self.forms.append(a.get("action", ""))
        if tag == "a" and a.get("href"):
            self._href, self._text = a["href"].strip(), []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag == "a" and self._href is not None:
            self.anchors.append((self._href, " ".join("".join(self._text).split())))
            self._href = None


def _clean_url(url: str) -> str:
    return url.strip().rstrip(".,;:!?)'\"")


def unwrap_url(url: str) -> str:
    """Strip common security/redirect wrappers so we analyse the real destination."""
    parts = urlsplit(url)
    host = (parts.hostname or "").lower()
    q = parse_qs(parts.query)
    if host.endswith("safelinks.protection.outlook.com") and "url" in q:
        return q["url"][0]
    if host in ("google.com", "www.google.com") and parts.path == "/url":
        return (q.get("q") or q.get("url") or [url])[0]
    return url


def _sniff(data: bytes) -> str:
    for magic, name in _MAGIC:
        if data.startswith(magic):
            return name
    if len(data) > 0x8006 and data[0x8001:0x8006] == b"CD001":
        return "ISO 9660 disk image"
    head = data[:2048].lower()
    if b"<html" in head or b"<!doctype html" in head or b"<script" in head or b"<form" in head:
        return "HTML"
    if b"<svg" in head:
        return "SVG"
    return "unknown/text"


def analyze_attachment(filename: str, declared: str, data: bytes) -> tuple[Attachment, list[Finding]]:
    name = filename.lower()
    ext = "." + name.rsplit(".", 1)[-1] if "." in name else ""
    detected = _sniff(data)
    att = Attachment(filename=filename, declared_type=declared, detected_type=detected, size=len(data),
                     md5=hashlib.md5(data).hexdigest(), sha1=hashlib.sha1(data).hexdigest(),
                     sha256=hashlib.sha256(data).hexdigest())
    f: list[Finding] = []

    labels = name.split(".")
    if len(labels) >= 3 and "." + labels[-2] in LURE_EXT and ext in RISKY_EXT | {".zip"}:
        att.flags.append("double-extension")
        f.append(Finding("DOUBLE_EXTENSION", "high", f"Attachment '{filename}' disguises a {ext} file as .{labels[-2]}.", 10, "T1036.007"))
    if ext in MACRO_EXT:
        att.flags.append("macro-enabled")
        f.append(Finding("MACRO_ATTACHMENT", "high", f"Macro-enabled Office attachment '{filename}'.", 8, "T1566.001"))
    elif ext in RISKY_EXT:
        att.flags.append("risky-extension")
        why = "HTML/SVG attachments are a common credential-harvesting vector" if ext in {".html", ".htm", ".shtml", ".svg"} else "executable/container type"
        f.append(Finding("RISKY_ATTACHMENT", "high", f"Attachment '{filename}' has high-risk extension {ext} ({why}).", 8, "T1566.001"))
    exp = EXPECTED_MAGIC.get(ext)
    if exp and detected not in (exp, "unknown/text"):
        att.flags.append("type-mismatch")
        f.append(Finding("TYPE_MISMATCH", "medium", f"'{filename}' extension implies {exp} but content is {detected}.", 6, "T1036.008"))
    guessed = mimetypes.guess_type(name)[0]
    if guessed and declared and declared != "application/octet-stream" and guessed != declared:
        att.flags.append("mime-mismatch")
    if detected == "ZIP/OOXML":
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as zf:
                if any(i.flag_bits & 0x1 for i in zf.infolist()):
                    att.flags.append("encrypted-archive")
                    f.append(Finding("ENCRYPTED_ARCHIVE", "high", f"'{filename}' is password-protected, a classic gateway-evasion trick.", 8, "T1027.013"))
                inner = [i.filename for i in zf.infolist() if "." + i.filename.lower().rsplit(".", 1)[-1] in RISKY_EXT]
                if inner and ext == ".zip":
                    att.flags.append("risky-archive-content")
                    f.append(Finding("RISKY_ARCHIVE_CONTENT", "high", f"Archive contains high-risk files: {', '.join(inner[:5])}.", 8, "T1566.001"))
        except zipfile.BadZipFile:
            pass
    return att, f


def extract_iocs(msg: EmailMessage, header: HeaderReport | None = None,
                 allowlist: set[str] = DEFAULT_ALLOWLIST) -> IOCReport:
    urls: dict[str, str] = {}
    body_ips: set[str] = set()
    attachments: list[Attachment] = []
    findings: list[Finding] = []
    anchors: list[tuple[str, str]] = []
    forms: list[str] = []

    for part in msg.walk():
        if part.is_multipart():
            continue
        ctype = part.get_content_type()
        filename = part.get_filename()
        if filename or part.is_attachment():
            data = part.get_payload(decode=True) or b""
            att, f = analyze_attachment(filename or "unnamed", ctype, data)
            attachments.append(att)
            findings.extend(f)
            continue
        if ctype not in ("text/plain", "text/html"):
            continue
        try:
            text = part.get_content()
        except Exception:
            text = (part.get_payload(decode=True) or b"").decode("utf-8", errors="replace")
        text = refang(text)
        source = "body:html" if ctype == "text/html" else "body:text"
        if ctype == "text/html":
            p = _LinkParser()
            p.feed(text)
            for link in p.links:
                if re.match(r"^(https?|ftp)://", link, re.I):
                    urls.setdefault(_clean_url(link), source)
            anchors.extend(p.anchors)
            forms.extend(p.forms)
        for u in URL_RE.findall(text):
            urls.setdefault(_clean_url(u), source)
        body_ips.update(ip for ip in IPV4_RE.findall(text) if not is_internal_ip(ip))

    iocs: list[IOC] = []
    domains: dict[str, str] = {}
    for raw_url, src in urls.items():
        url = unwrap_url(raw_url)
        host = (urlsplit(url).hostname or "").lower()
        allow = org_domain(host) in allowlist
        iocs.append(IOC("url", url, src, skip_enrichment=allow,
                        note="allowlisted" if allow else ("unwrapped from redirect" if url != raw_url else "")))
        if host and is_valid_ip(host):
            body_ips.add(host)
            findings.append(Finding("IP_LITERAL_URL", "medium", f"URL uses a raw IP address as host: {host}.", 6))
        elif host:
            domains.setdefault(host, src)
            if org_domain(host) in SHORTENERS:
                findings.append(Finding("URL_SHORTENER", "low", f"URL shortener hides the destination: {host}.", 4))
            if brand := lookalike_brand(host):
                findings.append(Finding("LOOKALIKE_URL_DOMAIN", "high", f"Link domain {host} imitates '{brand}'.", 12, "T1583.001"))
        if re.search(r"[?&][^=]+=[\w.+-]+(?:@|%40)[\w-]+\.", url):
            findings.append(Finding("RECIPIENT_IN_URL", "medium", "URL pre-fills the recipient's email address (personalised credential-harvesting link).", 6, "T1598.003"))

    for host, src in domains.items():
        allow = org_domain(host) in allowlist
        iocs.append(IOC("domain", host, src, skip_enrichment=allow, note="allowlisted" if allow else ""))

    # Deceptive anchors: visible text shows one domain, href goes to another.
    for href, text in anchors:
        if LOOKS_LIKE_URL.match(text or ""):
            shown = urlsplit(text if "://" in text else "http://" + text).hostname or ""
            real = urlsplit(unwrap_url(href)).hostname or ""
            if shown and real and org_domain(shown) != org_domain(real):
                findings.append(Finding("DECEPTIVE_LINK_TEXT", "high", f"Link text shows '{shown}' but points to '{real}'.", 10, "T1566.002"))
    if forms:
        findings.append(Finding("HTML_FORM_IN_BODY", "high", "Message body contains an HTML form (inline credential capture).", 8, "T1598.003"))

    header_ips = header.external_ips if header else []
    for ip in header_ips:
        src = "header:originating" if header and ip == header.originating_ip else "header:received"
        iocs.append(IOC("ip", ip, src))
    for ip in sorted(body_ips - set(header_ips)):
        iocs.append(IOC("ip", ip, "body"))
    for att in attachments:
        iocs.append(IOC("hash", att.sha256, f"attachment:{att.filename}"))

    if any(i.type == "url" and not i.skip_enrichment for i in iocs):
        findings.append(Finding("CONTAINS_LINKS", "info", f"{sum(1 for i in iocs if i.type == 'url' and not i.skip_enrichment)} non-allowlisted URL(s) present.", 0, "T1566.002"))

    # De-duplicate findings (same code + description)
    seen, unique = set(), []
    for fd in findings:
        key = (fd.code, fd.description)
        if key not in seen:
            seen.add(key)
            unique.append(fd)
    return IOCReport(iocs=iocs, attachments=attachments, findings=unique)
