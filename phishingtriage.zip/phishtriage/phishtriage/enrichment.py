"""Threat-intel enrichment clients: VirusTotal v3, AbuseIPDB v2, Hybrid Analysis v2.

Design points (see docs/API_INTEGRATION.md):
  * Lookups only. Nothing is ever uploaded/submitted, so private URLs and
    attachments never leave your environment (OPSEC).
  * Per-provider rate limiting (VT public API = 4 req/min) with 429 back-off.
  * On-disk JSON cache keyed by provider+indicator to preserve free-tier quota.
  * Offline mode: raw API-shaped fixtures are fed through the *same* normalisers,
    so demos and tests exercise real parsing code without API keys.
"""
from __future__ import annotations

import base64
import json
import logging
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from urllib.parse import quote

import requests

from .ioc_extractor import IOC

log = logging.getLogger(__name__)
NOT_FOUND = {"_not_found": True}
USER_AGENT = "phishtriage/1.0 (+SOC triage automation)"


@dataclass
class EnrichmentResult:
    provider: str
    ioc_type: str
    value: str
    found: bool = False
    score: int | None = None          # normalised 0-100 risk
    verdict: str = "unknown"          # malicious | suspicious | low | clean | unknown | error
    details: dict = field(default_factory=dict)
    link: str | None = None
    error: str | None = None
    cached: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


def verdict_for(score: int | None) -> str:
    if score is None:
        return "unknown"
    if score >= 70:
        return "malicious"
    if score >= 30:
        return "suspicious"
    return "low" if score > 0 else "clean"


class RateLimiter:
    def __init__(self, per_minute: float | None):
        self.interval = 60.0 / per_minute if per_minute else 0.0
        self._last = 0.0

    def wait(self) -> None:
        if not self.interval:
            return
        elapsed = time.monotonic() - self._last
        if elapsed < self.interval:
            time.sleep(self.interval - elapsed)
        self._last = time.monotonic()


class DiskCache:
    def __init__(self, path: str | Path, ttl_hours: float = 24):
        self.path = Path(path)
        self.ttl = ttl_hours * 3600
        try:
           self._data = json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
        except json.JSONDecodeError:
            self._data = {}

    def get(self, key: str):
        entry = self._data.get(key)
        if entry and time.time() - entry["ts"] < self.ttl:
            return entry["value"]
        return None

    def set(self, key: str, value) -> None:
        self._data[key] = {"ts": time.time(), "value": value}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._data, indent=1), encoding="utf-8")


class BaseClient:
    name = ""
    env_var = ""
    supports: set[str] = set()
    default_rpm: float | None = None

    def __init__(self, api_key: str | None = None, cache: DiskCache | None = None,
                 fixtures: dict | None = None, per_minute: float | None = None, timeout: int = 20):
        self.api_key = api_key or os.getenv(self.env_var)
        self.cache = cache
        self.fixtures = fixtures
        self.timeout = timeout
        self.limiter = RateLimiter(per_minute if per_minute is not None else self.default_rpm)
        self.session = requests.Session()
        self.session.headers["User-Agent"] = USER_AGENT

    @property
    def enabled(self) -> bool:
        return self.fixtures is not None or bool(self.api_key)

    def lookup(self, ioc_type: str, value: str) -> EnrichmentResult | None:
        if ioc_type not in self.supports or not self.enabled:
            return None
        cached = False
        if self.fixtures is not None:
            raw = self.fixtures.get(self.name, {}).get(value, NOT_FOUND)
        else:
            key = f"{self.name}:{ioc_type}:{value}"
            raw = self.cache.get(key) if self.cache else None
            if raw is not None:
                cached = True
            else:
                try:
                    raw = self._fetch(ioc_type, value)
                except requests.RequestException as exc:
                    log.warning("%s lookup failed for %s: %s", self.name, value, exc)
                    return EnrichmentResult(self.name, ioc_type, value, verdict="error", error=str(exc))
                if self.cache:
                    self.cache.set(key, raw)
        result = self._normalize(ioc_type, value, raw)
        result.cached = cached
        return result

    def _request(self, method: str, url: str, **kwargs):
        for attempt in range(4):
            self.limiter.wait()
            resp = self.session.request(method, url, timeout=self.timeout, **kwargs)
            if resp.status_code == 429:
                backoff = int(resp.headers.get("Retry-After", 15 * (attempt + 1)))
                log.info("%s rate-limited; sleeping %ss", self.name, backoff)
                time.sleep(backoff)
                continue
            if resp.status_code == 404:
                return NOT_FOUND
            resp.raise_for_status()
            return resp.json()
        raise requests.HTTPError(f"{self.name}: still rate-limited after retries")

    def _fetch(self, ioc_type: str, value: str):  # pragma: no cover - abstract
        raise NotImplementedError

    def _normalize(self, ioc_type: str, value: str, raw) -> EnrichmentResult:  # pragma: no cover
        raise NotImplementedError


# ------------------------------------------------------------------ VirusTotal
def vt_url_id(url: str) -> str:
    """VT v3 URL identifier: unpadded URL-safe base64 of the URL."""
    return base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")


class VirusTotalClient(BaseClient):
    name = "virustotal"
    env_var = "VT_API_KEY"
    supports = {"url", "domain", "ip", "hash"}
    default_rpm = 4  # public API limit
    BASE = "https://www.virustotal.com/api/v3"
    _PATHS = {"url": "urls", "domain": "domains", "ip": "ip_addresses", "hash": "files"}
    _GUI = {"domain": "domain", "ip": "ip-address", "hash": "file"}

    def _fetch(self, ioc_type, value):
        ident = vt_url_id(value) if ioc_type == "url" else value
        return self._request("GET", f"{self.BASE}/{self._PATHS[ioc_type]}/{ident}",
                             headers={"x-apikey": self.api_key, "accept": "application/json"})

    def _link(self, ioc_type, value):
        if ioc_type == "url":
            return f"https://www.virustotal.com/gui/search/{quote(value, safe='')}"
        return f"https://www.virustotal.com/gui/{self._GUI[ioc_type]}/{value}"

    def _normalize(self, ioc_type, value, raw):
        link = self._link(ioc_type, value)
        if raw.get("_not_found"):
            return EnrichmentResult(self.name, ioc_type, value, found=False, link=link,
                                    details={"note": "not present in VT dataset"})
        attrs = raw.get("data", {}).get("attributes", {})
        stats = attrs.get("last_analysis_stats", {})
        mal, sus = int(stats.get("malicious", 0)), int(stats.get("suspicious", 0))
        engines = sum(v for v in stats.values() if isinstance(v, int))
        score = min(100, mal * 12 + sus * 4)
        details = {"malicious": mal, "suspicious": sus, "engines": engines,
                   "reputation": attrs.get("reputation"), "summary": f"{mal}/{engines} malicious"}
        if ioc_type == "hash":
            details["name"] = attrs.get("meaningful_name")
            details["file_type"] = attrs.get("type_description")
            label = (attrs.get("popular_threat_classification") or {}).get("suggested_threat_label")
            if label:
                details["threat_label"] = label
        if ioc_type in ("domain", "ip"):
            details["as_owner"] = attrs.get("as_owner")
            details["country"] = attrs.get("country")
            if attrs.get("categories"):
                details["categories"] = sorted(set(attrs["categories"].values()))
        return EnrichmentResult(self.name, ioc_type, value, found=True, score=score,
                                verdict=verdict_for(score), details=details, link=link)


# ------------------------------------------------------------------ AbuseIPDB
class AbuseIPDBClient(BaseClient):
    name = "abuseipdb"
    env_var = "ABUSEIPDB_API_KEY"
    supports = {"ip"}
    default_rpm = 30
    URL = "https://api.abuseipdb.com/api/v2/check"

    def _fetch(self, ioc_type, value):
        return self._request("GET", self.URL, params={"ipAddress": value, "maxAgeInDays": 90},
                             headers={"Key": self.api_key, "Accept": "application/json"})

    def _normalize(self, ioc_type, value, raw):
        link = f"https://www.abuseipdb.com/check/{value}"
        data = raw.get("data") if isinstance(raw, dict) else None
        if not data:
            return EnrichmentResult(self.name, ioc_type, value, found=False, link=link)
        score = int(data.get("abuseConfidenceScore", 0))
        if data.get("isWhitelisted"):
            score = min(score, 10)
        details = {k: data.get(k) for k in ("abuseConfidenceScore", "totalReports", "numDistinctUsers",
                                             "countryCode", "isp", "usageType", "domain",
                                             "lastReportedAt", "isWhitelisted", "isTor")}
        details["summary"] = f"{score}% confidence, {data.get('totalReports', 0)} reports"
        return EnrichmentResult(self.name, ioc_type, value, found=data.get("totalReports", 0) > 0 or score > 0,
                                score=score, verdict=verdict_for(score), details=details, link=link)


# ------------------------------------------------------------------ Hybrid Analysis
class HybridAnalysisClient(BaseClient):
    name = "hybrid_analysis"
    env_var = "HYBRID_ANALYSIS_API_KEY"
    supports = {"hash"}
    default_rpm = 20
    BASE = "https://www.hybrid-analysis.com/api/v2"

    def _headers(self):
        # HA requires a "Falcon Sandbox" user-agent on API calls.
        return {"api-key": self.api_key, "User-Agent": "Falcon Sandbox", "accept": "application/json"}

    def _fetch(self, ioc_type, value):
        try:  # Current API: GET /search/hash?hash=
            return self._request("GET", f"{self.BASE}/search/hash", params={"hash": value}, headers=self._headers())
        except requests.HTTPError as exc:  # Older deployments only accept POST form data
            if exc.response is not None and exc.response.status_code in (400, 405):
                return self._request("POST", f"{self.BASE}/search/hash", data={"hash": value}, headers=self._headers())
            raise

    def _normalize(self, ioc_type, value, raw):
        link = f"https://www.hybrid-analysis.com/sample/{value}"
        reports = raw.get("reports", []) if isinstance(raw, dict) else (raw or [])
        if isinstance(raw, dict) and raw.get("_not_found") or not reports:
            return EnrichmentResult(self.name, ioc_type, value, found=False, link=link,
                                    details={"note": "no public sandbox report"})
        verdicts = {(r.get("verdict") or "").lower() for r in reports}
        score = max(int(r.get("threat_score") or 0) for r in reports)
        if "malicious" in verdicts:
            score = max(score, 85)
        elif "suspicious" in verdicts:
            score = max(score, 50)
        top = max(reports, key=lambda r: r.get("threat_score") or 0)
        details = {"verdict": top.get("verdict"), "threat_score": top.get("threat_score"),
                   "av_detect": top.get("av_detect"), "family": top.get("vx_family"),
                   "environment": top.get("environment_description"), "reports": len(reports),
                   "summary": f"{top.get('verdict')} (threat score {top.get('threat_score')})"}
        return EnrichmentResult(self.name, ioc_type, value, found=True, score=score,
                                verdict=verdict_for(score), details=details, link=link)


# ------------------------------------------------------------------ orchestration
def build_clients(fixtures_path: str | None = None, cache_path: str | None = ".cache/enrichment.json",
                  cache_ttl_hours: float = 24) -> list[BaseClient]:
    fixtures = json.loads(Path(fixtures_path).read_text(encoding="utf-8")) if fixtures_path else None
    cache = DiskCache(cache_path, cache_ttl_hours) if cache_path and fixtures is None else None
    clients = [VirusTotalClient(cache=cache, fixtures=fixtures),
               AbuseIPDBClient(cache=cache, fixtures=fixtures),
               HybridAnalysisClient(cache=cache, fixtures=fixtures)]
    for c in clients:
        if not c.enabled:
            log.warning("%s disabled: set %s (or use --offline)", c.name, c.env_var)
    return clients


def enrich(iocs: list[IOC], clients: list[BaseClient]) -> list[EnrichmentResult]:
    results: list[EnrichmentResult] = []
    for ioc in iocs:
        if ioc.skip_enrichment:
            continue
        for client in clients:
            res = client.lookup(ioc.type, ioc.value)
            if res is not None:
                results.append(res)
    return results
