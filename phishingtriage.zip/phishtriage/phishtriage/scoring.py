"""Turn header findings, static findings and enrichment results into a triage verdict."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import asdict, dataclass, field

from .enrichment import EnrichmentResult, verdict_for
from .header_parser import HeaderReport
from .ioc_extractor import IOCReport
from .utils import SEVERITY_ORDER, Finding

HEADER_CAP = 45     # identity/authentication evidence
STATIC_CAP = 30     # content evidence (links, attachments)
INTEL_WEIGHT = 0.6  # reputation evidence (worst IOC)

ATTACK_NAMES = {
    "T1566.001": "Phishing: Spearphishing Attachment",
    "T1566.002": "Phishing: Spearphishing Link",
    "T1598.003": "Phishing for Information: Spearphishing Link",
    "T1656": "Impersonation",
    "T1036.007": "Masquerading: Double File Extension",
    "T1036.008": "Masquerading: Masquerade File Type",
    "T1583.001": "Acquire Infrastructure: Domains",
    "T1027.013": "Obfuscated Files or Information: Encrypted/Encoded File",
}


@dataclass
class IOCScore:
    type: str
    value: str
    source: str
    score: int | None
    verdict: str
    providers: dict = field(default_factory=dict)  # provider -> summary
    skipped: bool = False


@dataclass
class TriageVerdict:
    score: int
    verdict: str
    header_points: int
    static_points: int
    intel_points: int
    rationale: list[str]
    attack: list[dict]
    actions: list[str]
    ioc_scores: list[IOCScore]

    def to_dict(self) -> dict:
        return asdict(self)


def score_iocs(ioc_report: IOCReport, results: list[EnrichmentResult]) -> list[IOCScore]:
    by_key: dict[tuple, list[EnrichmentResult]] = defaultdict(list)
    for r in results:
        by_key[(r.ioc_type, r.value)].append(r)
    out = []
    for ioc in ioc_report.iocs:
        rs = by_key.get((ioc.type, ioc.value), [])
        # Worst-case aggregation: one credible provider flagging an IOC is enough
        # to act on in triage; averaging would let "not found" results dilute it.
        scores = [r.score for r in rs if r.found and r.score is not None]
        best = max(scores) if scores else None
        providers = {r.provider: (r.details.get("summary") or r.verdict) if r.found else
                     ("error" if r.error else "not found") for r in rs}
        out.append(IOCScore(ioc.type, ioc.value, ioc.source, best,
                            "allowlisted" if ioc.skip_enrichment else verdict_for(best),
                            providers, ioc.skip_enrichment))
    return out


def _actions(verdict: str, header: HeaderReport, iocs: list[IOCScore], ioc_report: IOCReport) -> list[str]:
    if verdict == "LOW RISK":
        return ["No automated containment required. Release if quarantined and close as benign/spam after analyst spot-check.",
                "If user-reported, thank the reporter and tune gateway rules if this was bulk/marketing mail."]
    bad = [i for i in iocs if i.verdict in ("malicious", "suspicious")]
    urls = [i.value for i in bad if i.type == "url"]
    doms = sorted({i.value for i in bad if i.type == "domain"})
    ips = [i.value for i in bad if i.type == "ip"]
    hashes = [i.value for i in bad if i.type == "hash"]
    a = [f"Search and purge all copies org-wide (Message-ID {header.message_id}; subject \"{header.subject}\"), "
         "e.g. M365 Threat Explorer / Content Search or Google Workspace Investigation tool."]
    senders = sorted({x for x in (header.auth.spf_domain, header.from_domain if header.auth.dmarc_computed == "pass" else None) if x})
    if senders:
        a.append(f"Block envelope sender domain(s) at the mail gateway: {', '.join(senders)}. "
                 "Do NOT block a spoofed legitimate From domain; rely on DMARC enforcement for it.")
    if doms or urls:
        a.append(f"Block at web proxy / DNS firewall: {', '.join(doms) if doms else 'URLs listed in section 6'}.")
    if ips:
        a.append(f"Block inbound SMTP / outbound traffic to: {', '.join(ips)}.")
    if hashes:
        a.append(f"Add attachment SHA256 to EDR/AV blocklist: {', '.join(h[:16] + '…' for h in hashes)}.")
    if urls or doms:
        a.append("Hunt proxy/DNS logs for any user who resolved or visited the phishing domains since the delivery time; "
                 "treat any hit as a credential compromise.")
    a.append("For users who clicked or submitted credentials: reset password, revoke sessions/refresh tokens, "
             "review MFA registrations and mailbox forwarding/inbox rules, check sign-in logs for the originating IPs.")
    a.append("Submit URLs to the brand owner/registrar abuse contacts and report to your phishing-intel sharing channel (e.g. ISAC).")
    return a


def triage(header: HeaderReport, ioc_report: IOCReport, results: list[EnrichmentResult]) -> TriageVerdict:
    ioc_scores = score_iocs(ioc_report, results)
    header_pts = min(HEADER_CAP, sum(f.points for f in header.findings))
    static_pts = min(STATIC_CAP, sum(f.points for f in ioc_report.findings))
    worst = max((i.score for i in ioc_scores if i.score is not None), default=0)
    intel_pts = round(INTEL_WEIGHT * worst)
    total = min(100, header_pts + static_pts + intel_pts)
    verdict = "MALICIOUS" if total >= 70 else "SUSPICIOUS" if total >= 40 else "LOW RISK"

    all_findings: list[Finding] = header.findings + ioc_report.findings
    ranked = sorted(all_findings, key=lambda f: (f.points, SEVERITY_ORDER[f.severity]), reverse=True)
    rationale = [f.description for f in ranked if f.points > 0][:5]
    worst_ioc = max((i for i in ioc_scores if i.score is not None), key=lambda i: i.score, default=None)
    if worst_ioc and worst_ioc.score >= 30:
        rationale.append(f"Highest-risk IOC ({worst_ioc.type}) scored {worst_ioc.score}/100: "
                         + "; ".join(f"{k}: {v}" for k, v in worst_ioc.providers.items()))

    techniques: dict[str, list[str]] = defaultdict(list)
    for f in all_findings:
        if f.attack:
            techniques[f.attack].append(f.code)
    if any(i.type == "url" and i.verdict in ("malicious", "suspicious") for i in ioc_scores):
        techniques["T1566.002"].append("MALICIOUS_URL_INTEL")
    if any(i.type == "hash" and i.verdict in ("malicious", "suspicious") for i in ioc_scores):
        techniques["T1566.001"].append("MALICIOUS_ATTACHMENT_INTEL")
    attack = [{"id": t, "name": ATTACK_NAMES.get(t, t), "evidence": sorted(set(ev))} for t, ev in sorted(techniques.items())]

    return TriageVerdict(total, verdict, header_pts, static_pts, intel_pts, rationale, attack,
                         _actions(verdict, header, ioc_scores, ioc_report), ioc_scores)
