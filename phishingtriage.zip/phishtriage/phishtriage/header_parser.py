"""Parse raw RFC 5322 headers.

Produces: chronological routing hops, the originating (boundary) IP, SPF/DKIM/DMARC
results with independently recomputed *alignment*, and scored header findings.
See docs/PARSING_LOGIC.md for the reasoning behind each step.
"""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from email.message import EmailMessage
from email.utils import parseaddr, parsedate_to_datetime

from .utils import (
    BRANDS, Finding, brand_in_text, domain_of, is_internal_ip, is_valid_ip,
    lookalike_brand, org_domain,
)

_BRACKET_IP = re.compile(r"\[(?:IPv6:)?([0-9a-fA-F:.]+)\]")
_BARE_IPV4 = re.compile(r"\b((?:\d{1,3}\.){3}\d{1,3})\b")
_RCV_FROM = re.compile(r"^\s*from\s+(?P<helo>\S+)(?:\s+\((?P<detail>[^)]*)\))?", re.I)
_RCV_BY = re.compile(r"\bby\s+(?P<by>[^\s;()]+)", re.I)
_RCV_WITH = re.compile(r"\bwith\s+(?P<with>[^;]+?)(?=\s+(?:id|for|via)\b|;|$)", re.I)

SUSPICIOUS_MAILERS = ("phpmailer", "swiftmailer", "king phisher", "sendblaster", "atomic mail", "leaf phpmailer")


@dataclass
class Hop:
    index: int
    from_helo: str | None
    from_ip: str | None
    by_host: str | None
    protocol: str | None
    timestamp: str | None
    delay_seconds: float | None
    external: bool
    raw: str


@dataclass
class AuthResults:
    source: str = "none"
    spf: str | None = None
    spf_domain: str | None = None
    dkim: list[dict] = field(default_factory=list)
    dmarc: str | None = None
    dmarc_policy: str | None = None
    header_from: str | None = None
    sender_ip: str | None = None
    spf_aligned: bool | None = None
    dkim_aligned: bool | None = None
    dmarc_computed: str | None = None


@dataclass
class HeaderReport:
    subject: str | None
    date: str | None
    to: str | None
    from_display: str
    from_address: str
    from_domain: str
    reply_to: str | None
    return_path: str | None
    message_id: str | None
    x_mailer: str | None
    hops: list[Hop]
    external_ips: list[str]
    originating_ip: str | None
    originating_ip_source: str | None
    auth: AuthResults
    findings: list[Finding]

    def to_dict(self) -> dict:
        return asdict(self)


def _h(msg: EmailMessage, name: str) -> str | None:
    value = msg.get(name)
    return " ".join(str(value).split()) if value is not None else None


# --------------------------------------------------------------------------- hops
def parse_received(value: str, index: int = 0) -> Hop:
    """Parse one Received header into its from/by/with/date components."""
    v = " ".join(str(value).split())
    head, sep, date_part = v.rpartition(";")
    if not sep:
        head, date_part = v, ""

    helo = ip = None
    rest = head
    m = _RCV_FROM.search(head)
    if m:
        helo = m.group("helo")
        detail = m.group("detail") or ""
        # The IP in the parenthetical is what the *receiving* server observed (TCP peer);
        # the HELO string is attacker-controlled, so it's only a fallback.
        candidates = _BRACKET_IP.findall(detail) or _BARE_IPV4.findall(detail) or _BRACKET_IP.findall(helo)
        candidates = [c for c in candidates if is_valid_ip(c)]
        ip = candidates[-1] if candidates else None
        rest = head[m.end():]

    by = _RCV_BY.search(rest)
    proto = _RCV_WITH.search(rest)
    ts = None
    if date_part.strip():
        try:
            ts = parsedate_to_datetime(date_part.strip()).isoformat()
        except (TypeError, ValueError):
            ts = None

    return Hop(
        index=index, from_helo=helo, from_ip=ip,
        by_host=by.group("by") if by else None,
        protocol=re.sub(r"\s*\(.*?\)", "", proto.group("with")).strip()[:40] if proto else None,
        timestamp=ts, delay_seconds=None,
        external=bool(ip and not is_internal_ip(ip)), raw=v,
    )


def _build_hops(msg: EmailMessage) -> list[Hop]:
    raw = msg.get_all("Received") or []
    # Headers are prepended by each MTA, so the list is newest-first. Reverse it.
    hops = [parse_received(str(r)) for r in reversed(raw)]
    prev = None
    for i, hop in enumerate(hops, start=1):
        hop.index = i
        if hop.timestamp and prev:
            from datetime import datetime
            hop.delay_seconds = (datetime.fromisoformat(hop.timestamp) - datetime.fromisoformat(prev)).total_seconds()
        prev = hop.timestamp or prev
    return hops


# --------------------------------------------------------------------------- auth
def _parse_auth(msg: EmailMessage) -> AuthResults:
    ar = AuthResults()
    values = msg.get_all("Authentication-Results") or []
    if values:
        # Only the TOPMOST header was added by our own boundary MTA. Lower ones can be
        # forged by the sender, so they are ignored.
        ar.source = "Authentication-Results (topmost)"
        v = " ".join(str(values[0]).split())
        if m := re.search(r"sender IP is ([0-9a-fA-F:.]+)", v, re.I):
            ar.sender_ip = m.group(1)
        for seg in v.split(";")[1:]:
            seg = seg.strip()
            if m := re.match(r"spf=(\w+)", seg, re.I):
                ar.spf = m.group(1).lower()
                if d := re.search(r"smtp\.mailfrom=([^\s;]+)", seg, re.I):
                    ar.spf_domain = domain_of(d.group(1))
            elif m := re.match(r"dkim=(\w+)", seg, re.I):
                d = re.search(r"header\.d=([^\s;]+)", seg, re.I) or re.search(r"header\.i=@?([^\s;]+)", seg, re.I)
                s = re.search(r"header\.s=([^\s;]+)", seg, re.I)
                ar.dkim.append({"result": m.group(1).lower(),
                                "domain": domain_of(d.group(1)) if d else None,
                                "selector": s.group(1) if s else None})
            elif m := re.match(r"dmarc=(\w+)", seg, re.I):
                ar.dmarc = m.group(1).lower()
                if p := re.search(r"\bp=(\w+)", seg, re.I):
                    ar.dmarc_policy = p.group(1).lower()
                if hf := re.search(r"header\.from=([^\s;]+)", seg, re.I):
                    ar.header_from = hf.group(1).lower()

    rspf = _h(msg, "Received-SPF")
    if rspf and ar.spf is None:
        ar.spf = rspf.split()[0].lower()
        ar.source = "Received-SPF" if ar.source == "none" else ar.source
        if m := re.search(r"envelope-from=<?([^\s;>]+)", rspf, re.I):
            ar.spf_domain = domain_of(m.group(1))

    # DKIM-Signature headers are *claims* (unverified). Use them to fill gaps only.
    for sig in msg.get_all("DKIM-Signature") or []:
        s = " ".join(str(sig).split())
        d = re.search(r"\bd=([^\s;]+)", s)
        sel = re.search(r"\bs=([^\s;]+)", s)
        if not d:
            continue
        match = next((x for x in ar.dkim if x.get("domain") == d.group(1).lower()), None)
        if match:
            match["selector"] = match["selector"] or (sel.group(1) if sel else None)
        elif not ar.dkim:
            ar.dkim.append({"result": "unverified", "domain": d.group(1).lower(),
                            "selector": sel.group(1) if sel else None})
    return ar


def _compute_alignment(ar: AuthResults, from_domain: str, return_path: str | None) -> None:
    """Recompute DMARC relaxed alignment ourselves instead of trusting 'pass' at face value."""
    fo = org_domain(from_domain)
    env = ar.spf_domain or domain_of(return_path)
    ar.spf_domain = env or None
    if ar.spf is not None:
        ar.spf_aligned = ar.spf == "pass" and bool(env) and org_domain(env) == fo
    passing = [d for d in ar.dkim if d["result"] == "pass" and d.get("domain")]
    if ar.dkim:
        ar.dkim_aligned = any(org_domain(d["domain"]) == fo for d in passing)
    ar.dmarc_computed = "pass" if (ar.spf_aligned or ar.dkim_aligned) else "fail"


def _originating_ip(msg: EmailMessage, hops: list[Hop], ar: AuthResults,
                    trusted_hosts: tuple[str, ...]) -> tuple[str | None, str | None]:
    """Most trustworthy source first: what OUR boundary MTA saw, then the Received chain."""
    rspf = _h(msg, "Received-SPF") or ""
    if (m := re.search(r"client-ip=([0-9a-fA-F:.]+)", rspf)) and is_valid_ip(m.group(1)) and not is_internal_ip(m.group(1)):
        return m.group(1), "Received-SPF client-ip (recorded by receiving MTA)"
    if ar.sender_ip and is_valid_ip(ar.sender_ip) and not is_internal_ip(ar.sender_ip):
        return ar.sender_ip, "Authentication-Results 'sender IP is'"
    if trusted_hosts:
        for hop in reversed(hops):  # newest first: walk inward while hops are ours
            if hop.by_host and any(hop.by_host.lower().endswith(t.lower()) for t in trusted_hosts):
                if hop.external:
                    return hop.from_ip, f"first external hop into trusted host {hop.by_host}"
            else:
                break
    for hop in hops:
        if hop.external:
            return hop.from_ip, "earliest external Received hop (unverified - may be forged)"
    if (xo := _h(msg, "X-Originating-IP")) and (m := re.search(r"[0-9a-fA-F:.]{7,}", xo)):
        return m.group(0), "X-Originating-IP header (client-supplied)"
    return None, None


# --------------------------------------------------------------------------- main
def analyze_headers(msg: EmailMessage, trusted_hosts: tuple[str, ...] = ()) -> HeaderReport:
    from_display, from_addr = parseaddr(_h(msg, "From") or "")
    from_domain = domain_of(from_addr)
    reply_to = parseaddr(_h(msg, "Reply-To") or "")[1] or None
    return_path = parseaddr(_h(msg, "Return-Path") or "")[1] or None
    message_id = _h(msg, "Message-ID")
    x_mailer = _h(msg, "X-Mailer") or _h(msg, "User-Agent")

    hops = _build_hops(msg)
    ar = _parse_auth(msg)
    _compute_alignment(ar, from_domain, return_path)
    orig_ip, orig_src = _originating_ip(msg, hops, ar, trusted_hosts)
    external_ips = list(dict.fromkeys(h.from_ip for h in hops if h.external))
    if orig_ip and orig_ip not in external_ips:
        external_ips.insert(0, orig_ip)

    findings = _header_findings(from_display, from_domain, reply_to, return_path,
                                message_id, x_mailer, hops, ar)
    return HeaderReport(
        subject=_h(msg, "Subject"), date=_h(msg, "Date"), to=_h(msg, "To"),
        from_display=from_display, from_address=from_addr, from_domain=from_domain,
        reply_to=reply_to, return_path=return_path, message_id=message_id, x_mailer=x_mailer,
        hops=hops, external_ips=external_ips, originating_ip=orig_ip,
        originating_ip_source=orig_src, auth=ar, findings=findings,
    )


def _header_findings(from_display, from_domain, reply_to, return_path, message_id,
                     x_mailer, hops, ar: AuthResults) -> list[Finding]:
    f: list[Finding] = []
    fo = org_domain(from_domain)
    env = ar.spf_domain

    # SPF
    if ar.spf in ("fail", "permerror"):
        f.append(Finding("SPF_FAIL", "high", f"SPF {ar.spf} for envelope domain {env}: sending IP not authorised.", 10))
    elif ar.spf == "softfail":
        f.append(Finding("SPF_SOFTFAIL", "medium", f"SPF softfail for envelope domain {env}.", 5))
    elif ar.spf in ("none", "neutral", "temperror"):
        f.append(Finding("SPF_WEAK", "low", f"SPF result '{ar.spf}' provides no sender assurance.", 2))
    elif ar.spf == "pass" and ar.spf_aligned is False:
        f.append(Finding("SPF_UNALIGNED", "medium",
                         f"SPF passed for {env}, which does NOT align with From domain {from_domain}. "
                         "The sender authenticated their own infrastructure, not the brand shown to the user.", 5))
    # DKIM
    if any(d["result"] in ("fail", "permerror") for d in ar.dkim):
        f.append(Finding("DKIM_FAIL", "high", "DKIM signature failed verification (body or headers altered, or forged).", 8))
    elif ar.dkim_aligned is False and any(d["result"] == "pass" for d in ar.dkim):
        doms = ", ".join(sorted({d["domain"] for d in ar.dkim if d.get("domain")}))
        f.append(Finding("DKIM_UNALIGNED", "medium", f"DKIM passed for d={doms}, which does not align with From domain {from_domain}.", 5))
    elif not ar.dkim:
        f.append(Finding("DKIM_ABSENT", "low", "Message carries no DKIM signature.", 2))
    # DMARC
    if ar.dmarc == "fail":
        pol = f" (published policy p={ar.dmarc_policy})" if ar.dmarc_policy else ""
        f.append(Finding("DMARC_FAIL", "high", f"DMARC failed for header.from={ar.header_from or from_domain}{pol}. "
                         "The visible From address is spoofed.", 15, "T1656"))
    elif ar.dmarc in (None, "none", "bestguesspass") and ar.dmarc_computed == "fail":
        f.append(Finding("DMARC_WOULD_FAIL", "medium", "No enforced DMARC verdict, but neither SPF nor DKIM aligns with the From domain.", 8, "T1656"))
    elif ar.dmarc == "pass" and ar.dmarc_computed == "fail":
        f.append(Finding("DMARC_DISCREPANCY", "info", "Gateway reported DMARC pass but local alignment check disagrees; review manually.", 0))
    # Identity mismatches
    if reply_to and org_domain(domain_of(reply_to)) != fo:
        f.append(Finding("REPLY_TO_MISMATCH", "medium", f"Reply-To ({reply_to}) diverts replies away from the From domain ({from_domain}).", 8))
    if return_path and org_domain(domain_of(return_path)) != fo and not any(x.code == "SPF_UNALIGNED" for x in f):
        f.append(Finding("RETURN_PATH_MISMATCH", "low", f"Return-Path domain differs from From domain (common for ESPs; weak signal alone).", 3))
    if "@" in (from_display or ""):
        disp_dom = domain_of(re.search(r"[\w.+-]+@[\w.-]+", from_display).group(0)) if re.search(r"[\w.+-]+@[\w.-]+", from_display) else ""
        if disp_dom and org_domain(disp_dom) != fo:
            f.append(Finding("DISPLAY_NAME_ADDRESS", "high", f"Display name embeds a different address ({disp_dom}) than the real sender ({from_domain}).", 8, "T1656"))
    if (brand := brand_in_text(from_display)) and fo not in BRANDS[brand]:
        f.append(Finding("DISPLAY_NAME_IMPERSONATION", "high", f"Display name references '{brand}' but mail is from unrelated domain {from_domain}.", 10, "T1656"))
    if brand := lookalike_brand(from_domain):
        f.append(Finding("LOOKALIKE_SENDER_DOMAIN", "high", f"Sender domain {from_domain} imitates '{brand}'.", 12, "T1583.001"))
    if message_id and (m := re.search(r"@([^>\s]+)", message_id)) and org_domain(m.group(1)) != fo:
        f.append(Finding("MESSAGE_ID_MISMATCH", "low", f"Message-ID generated by {m.group(1)}, not the From domain.", 3))
    if x_mailer and any(s in x_mailer.lower() for s in SUSPICIOUS_MAILERS):
        f.append(Finding("BULK_MAILER", "low", f"Sent with scripted/bulk mailer: {x_mailer}.", 3))
    # Routing anomalies
    if not hops:
        f.append(Finding("NO_RECEIVED", "medium", "No Received headers: message may have been injected or headers stripped.", 5))
    for hop in hops:
        if hop.delay_seconds is not None and hop.delay_seconds < -60:
            f.append(Finding("HOP_TIME_REVERSAL", "low", f"Hop {hop.index} is timestamped {abs(hop.delay_seconds):.0f}s before the previous hop (clock skew or forged hop).", 2))
        elif hop.delay_seconds is not None and hop.delay_seconds > 3600:
            f.append(Finding("HOP_DELAY", "info", f"Hop {hop.index} delayed {hop.delay_seconds/3600:.1f}h (queueing/greylisting).", 0))
    return f
