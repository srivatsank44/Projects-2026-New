"""Render the triage result as an analyst-ready Markdown report and machine-readable JSON."""
from __future__ import annotations

import json
from datetime import datetime, timezone

from . import __version__
from .enrichment import EnrichmentResult
from .header_parser import HeaderReport
from .ioc_extractor import IOCReport
from .scoring import TriageVerdict
from .utils import SEVERITY_ORDER, defang

_ICON = {"MALICIOUS": "🔴", "SUSPICIOUS": "🟠", "LOW RISK": "🟢"}


def _esc(v) -> str:
    return "—" if v in (None, "", []) else str(v).replace("|", "\\|")


def _yn(v) -> str:
    return "—" if v is None else ("✅ yes" if v else "❌ no")


def build_json(meta: dict, header: HeaderReport, iocs: IOCReport, results: list[EnrichmentResult],
               verdict: TriageVerdict) -> dict:
    return {"meta": meta, "verdict": verdict.to_dict(), "headers": header.to_dict(),
            "iocs": iocs.to_dict(), "enrichment": [r.to_dict() for r in results]}


def build_markdown(meta: dict, header: HeaderReport, iocs: IOCReport, results: list[EnrichmentResult],
                   v: TriageVerdict) -> str:
    L: list[str] = []
    w = L.append
    w(f"# Phishing Triage Report — {meta['case_id']}\n")
    w("| Field | Value |\n|---|---|")
    w(f"| Generated | {meta['generated']} |")
    w(f"| Tool | phishtriage v{__version__} ({meta['mode']}) |")
    w(f"| Source file | `{meta['source']}` |")
    w(f"| Message SHA256 | `{meta['sha256']}` |\n")

    w(f"## 1. Verdict: {_ICON[v.verdict]} **{v.verdict}** — risk score {v.score}/100\n")
    w(f"Score composition: header/authentication **{v.header_points}**/45 · content **{v.static_points}**/30 · "
      f"threat intel **{v.intel_points}**/60 (0.6 × worst IOC score), capped at 100.\n")
    w("**Key evidence:**\n")
    for r in v.rationale:
        w(f"- {r}")
    w("")

    w("## 2. Message Summary\n")
    w("| Header | Value |\n|---|---|")
    for k, val in (("Subject", header.subject), ("Date", header.date), ("To", header.to),
                   ("From (display)", header.from_display), ("From (address)", header.from_address),
                   ("Reply-To", header.reply_to), ("Return-Path", header.return_path),
                   ("Message-ID", header.message_id), ("X-Mailer", header.x_mailer)):
        w(f"| {k} | {_esc(val)} |")
    w("")

    a = header.auth
    w("## 3. Authentication & Alignment\n")
    w(f"Parsed from: {a.source}. Alignment is **recomputed locally** (DMARC relaxed mode, organisational-domain match "
      f"against From domain `{header.from_domain}`) rather than trusting the gateway verdict.\n")
    w("| Mechanism | Result | Authenticated domain | Aligned with From? |\n|---|---|---|---|")
    w(f"| SPF | `{_esc(a.spf)}` | {_esc(a.spf_domain)} | {_yn(a.spf_aligned)} |")
    for d in a.dkim or [{"result": None, "domain": None, "selector": None}]:
        sel = f" (s={d['selector']})" if d.get("selector") else ""
        w(f"| DKIM | `{_esc(d['result'])}` | {_esc(d['domain'])}{sel} | {_yn(a.dkim_aligned)} |")
    pol = f" (p={a.dmarc_policy})" if a.dmarc_policy else ""
    w(f"| DMARC (reported) | `{_esc(a.dmarc)}`{pol} | {_esc(a.header_from)} | — |")
    w(f"| DMARC (recomputed) | `{a.dmarc_computed}` | — | SPF or DKIM aligned = pass |\n")

    w("## 4. Delivery Path (oldest → newest)\n")
    w("| # | From (HELO) | From IP | Received by | Protocol | Timestamp | Δ |\n|---|---|---|---|---|---|---|")
    for h in header.hops:
        ip = f"`{h.from_ip}`" + (" 🌐" if h.external else "") if h.from_ip else "—"
        delta = f"{h.delay_seconds:+.0f}s" if h.delay_seconds is not None else "—"
        w(f"| {h.index} | {_esc(h.from_helo)} | {ip} | {_esc(h.by_host)} | {_esc(h.protocol)} | {_esc(h.timestamp)} | {delta} |")
    w(f"\n**Originating IP:** `{_esc(header.originating_ip)}` — source: {_esc(header.originating_ip_source)}  ")
    w(f"🌐 = externally routable. All external hop IPs were extracted as IOCs: {', '.join(f'`{i}`' for i in header.external_ips) or '—'}\n")

    w("## 5. Findings\n")
    w("| Severity | Code | Points | Description | ATT&CK |\n|---|---|---|---|---|")
    for f in sorted(header.findings + iocs.findings, key=lambda x: (SEVERITY_ORDER[x.severity], x.points), reverse=True):
        w(f"| {f.severity.upper()} | `{f.code}` | {f.points} | {_esc(f.description)} | {_esc(f.attack)} |")
    w("")

    w("## 6. Indicators of Compromise & Enrichment\n")
    w("Indicators are defanged. Score = worst provider score (0-100). Provider columns: VirusTotal / AbuseIPDB / Hybrid Analysis.\n")
    w("| Type | Indicator | Found in | VirusTotal | AbuseIPDB | Hybrid Analysis | Score | Verdict |\n|---|---|---|---|---|---|---|---|")
    for s in v.ioc_scores:
        val = s.value if s.type == "hash" else defang(s.value)
        p = s.providers
        cols = [p.get("virustotal", "n/a"), p.get("abuseipdb", "n/a"), p.get("hybrid_analysis", "n/a")]
        if s.skipped:
            cols = ["skipped"] * 3
        w(f"| {s.type} | `{_esc(val)}` | {s.source} | {' | '.join(_esc(c) for c in cols)} | {_esc(s.score)} | **{s.verdict}** |")
    w("")
    ctx = [r for r in results if r.found and (r.details.get("isp") or r.details.get("family") or r.details.get("threat_label"))]
    if ctx:
        w("**Additional context:**\n")
        for r in ctx:
            d = r.details
            if r.provider == "abuseipdb":
                w(f"- `{r.value}` — {d.get('isp')} ({d.get('countryCode')}), usage: {d.get('usageType')}, last reported {d.get('lastReportedAt')}.")
            elif r.provider == "hybrid_analysis":
                w(f"- Attachment `{r.value[:16]}…` — sandbox family **{d.get('family')}**, AV detect {d.get('av_detect')}%, env: {d.get('environment')}.")
            elif d.get("threat_label"):
                w(f"- `{r.value[:16]}…` — VirusTotal label **{d['threat_label']}** ({d.get('file_type')}).")
        w("")

    w("## 7. Attachments\n")
    if iocs.attachments:
        w("| Filename | Declared type | Detected (magic bytes) | Size | SHA256 | Flags |\n|---|---|---|---|---|---|")
        for at in iocs.attachments:
            w(f"| `{_esc(at.filename)}` | {at.declared_type} | {at.detected_type} | {at.size} B | `{at.sha256}` | {', '.join(at.flags) or '—'} |")
        w("\nMD5/SHA1 are available in the JSON report. Attachments were hashed only; nothing was uploaded to third parties.\n")
    else:
        w("No attachments.\n")

    w("## 8. MITRE ATT&CK Mapping\n")
    if v.attack:
        w("| Technique | Name | Evidence |\n|---|---|---|")
        for t in v.attack:
            w(f"| {t['id']} | {t['name']} | {', '.join(f'`{e}`' for e in t['evidence'])} |")
    else:
        w("No techniques mapped.")
    w("")

    w("## 9. Recommended Response Actions\n")
    for i, act in enumerate(v.actions, 1):
        w(f"{i}. {act}")
    w("")

    w("## 10. Analyst Notes & Limitations\n")
    w("- Authentication results are taken from the **topmost** Authentication-Results header (added by the receiving "
      "gateway); lower headers are attacker-controllable and ignored.")
    w("- Received hops below the organisation's boundary MTA can be forged; the originating IP is chosen from the "
      "most trustworthy available source (see section 4).")
    w("- 'Not found' in a reputation service is **not** evidence of safety — freshly registered phishing "
      "infrastructure frequently has no history.")
    w("- Automated verdicts support, not replace, analyst judgement. Confirm before tenant-wide purge.")
    if meta["mode"] != "live":
        w(f"- ⚠️ Enrichment mode: **{meta['mode']}**. Provider data in this report is "
          + ("from offline fixtures (demo)." if meta["mode"] == "offline-fixtures" else "not collected."))
    return "\n".join(L) + "\n"


def make_meta(source: str, sha256: str, mode: str) -> dict:
    now = datetime.now(timezone.utc)
    return {"case_id": f"PT-{now:%Y%m%d}-{sha256[:8].upper()}", "generated": now.strftime("%Y-%m-%d %H:%M:%SZ"),
            "source": source, "sha256": sha256, "mode": mode}


def dump_json(data: dict) -> str:
    return json.dumps(data, indent=2, default=str)
