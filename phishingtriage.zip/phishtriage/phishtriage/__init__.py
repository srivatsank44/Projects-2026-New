"""phishtriage - automated phishing email analysis and IOC triage."""
__version__ = "1.0.0"
