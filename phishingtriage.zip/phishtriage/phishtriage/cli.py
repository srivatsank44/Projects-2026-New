"""Command-line entry point.

Exit codes (for SOAR / CI pipelines): 0 = low risk, 1 = suspicious, 2 = malicious, 3 = error.
"""
from __future__ import annotations

import argparse
import hashlib
import logging
import sys
from email import policy
from email.parser import BytesParser
from pathlib import Path

from .enrichment import build_clients, enrich
from .header_parser import analyze_headers
from .ioc_extractor import extract_iocs
from .report import build_json, build_markdown, dump_json, make_meta
from .scoring import triage

EXIT = {"LOW RISK": 0, "SUSPICIOUS": 1, "MALICIOUS": 2}


def analyze_file(path: Path, clients, trusted_hosts=(), mode="live"):
    raw = path.read_bytes()
    msg = BytesParser(policy=policy.default).parsebytes(raw)
    header = analyze_headers(msg, tuple(trusted_hosts))
    iocs = extract_iocs(msg, header)
    results = enrich(iocs.iocs, clients) if clients else []
    verdict = triage(header, iocs, results)
    meta = make_meta(path.name, hashlib.sha256(raw).hexdigest(), mode)
    return meta, header, iocs, results, verdict


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="phishtriage", description="Automated phishing email triage.")
    ap.add_argument("inputs", nargs="+", help=".eml file(s) or directories containing .eml files")
    ap.add_argument("-o", "--out", default="reports", help="output directory (default: reports/)")
    ap.add_argument("--offline", metavar="FIXTURES", help="use offline JSON fixtures instead of live APIs")
    ap.add_argument("--no-enrich", action="store_true", help="skip threat-intel lookups entirely")
    ap.add_argument("--trusted-host", action="append", default=[],
                    help="your boundary MTA hostname suffix (repeatable), improves originating-IP accuracy")
    ap.add_argument("--cache", default=".cache/enrichment.json", help="enrichment cache path ('' disables)")
    ap.add_argument("--format", default="md,json", help="comma list of md,json (default both)")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING, format="%(levelname)s %(message)s")
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass

    files: list[Path] = []
    for item in map(Path, args.inputs):
        files.extend(sorted(item.glob("*.eml")) if item.is_dir() else [item])
    if not files:
        print("No .eml files found.", file=sys.stderr)
        return 3

    mode = "enrichment disabled" if args.no_enrich else ("offline-fixtures" if args.offline else "live")
    clients = [] if args.no_enrich else build_clients(args.offline, args.cache or None)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    formats = {f.strip() for f in args.format.split(",")}
    worst = 0
    for f in files:
        try:
            meta, header, iocs, results, verdict = analyze_file(f, clients, args.trusted_host, mode)
        except Exception as exc:  # keep batch runs going
            logging.error("Failed to analyse %s: %s", f, exc)
            worst = max(worst, 3)
            continue
        stem = f"{meta['case_id']}_{f.stem}"
        if "md" in formats:
            (out / f"{stem}.md").write_text(build_markdown(meta, header, iocs, results, verdict), encoding="utf-8")
        if "json" in formats:
            (out / f"{stem}.json").write_text(dump_json(build_json(meta, header, iocs, results, verdict)), encoding="utf-8")
        print(f"[{verdict.verdict:<10}] {verdict.score:>3}/100  {f.name}  ->  {out / stem}.*")
        worst = max(worst, EXIT[verdict.verdict])
    return worst
