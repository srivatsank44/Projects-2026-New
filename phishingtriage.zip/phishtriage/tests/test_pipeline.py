from phishtriage.cli import main
from phishtriage.enrichment import AbuseIPDBClient, HybridAnalysisClient, VirusTotalClient, vt_url_id


def test_vt_url_id_unpadded():
    assert vt_url_id("http://a.test/") == "aHR0cDovL2EudGVzdC8"


def test_normalisers():
    vt = VirusTotalClient(fixtures={})
    r = vt._normalize("ip", "1.2.3.4", {"data": {"attributes": {"last_analysis_stats": {"malicious": 6, "harmless": 50}}}})
    assert r.score == 72 and r.verdict == "malicious"
    ab = AbuseIPDBClient(fixtures={})
    r = ab._normalize("ip", "1.2.3.4", {"data": {"abuseConfidenceScore": 90, "totalReports": 3, "isWhitelisted": True}})
    assert r.score == 10  # allow-listed IPs are capped
    ha = HybridAnalysisClient(fixtures={})
    r = ha._normalize("hash", "x", [{"verdict": "suspicious", "threat_score": 20}])
    assert r.score == 50
    assert not ha._normalize("hash", "x", []).found


def test_offline_end_to_end(tmp_path, fixtures_path):
    code = main(["samples/m365_credential_phish.eml", "--offline", fixtures_path, "-o", str(tmp_path)])
    assert code == 2  # MALICIOUS
    md = next(tmp_path.glob("*.md")).read_text(encoding="utf-8")
    assert "MALICIOUS" in md and "hxxps://login[.]micros0ft-365-verify[.]test" in md


def test_benign_low_risk(tmp_path):
    assert main(["samples/benign_newsletter.eml", "--no-enrich", "-o", str(tmp_path)]) == 0
