from email import policy
from email.parser import BytesParser
from pathlib import Path

import pytest

SAMPLES = Path(__file__).resolve().parents[1] / "samples"


def load(name):
    return BytesParser(policy=policy.default).parsebytes((SAMPLES / name).read_bytes())


@pytest.fixture
def phish():
    return load("m365_credential_phish.eml")


@pytest.fixture
def benign():
    return load("benign_newsletter.eml")


@pytest.fixture
def fixtures_path():
    return str(SAMPLES / "mock_responses.json")
