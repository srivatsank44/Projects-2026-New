from phishtriage.header_parser import analyze_headers, parse_received
from phishtriage.utils import org_domain


def codes(report):
    return {f.code for f in report.findings}


def test_received_chain_is_chronological(phish):
    r = analyze_headers(phish)
    assert [h.from_ip for h in r.hops] == ["198.51.100.14", "203.0.113.77", "10.20.1.15"]
    assert r.hops[1].by_host == "mx-gw01.acmecorp.example"
    assert r.hops[1].delay_seconds == 2.0


def test_observed_ip_preferred_over_helo():
    hop = parse_received("from [192.168.1.23] (unknown [198.51.100.14]) by mx.example.com "
                         "with ESMTPSA id 1; Tue, 15 Sep 2026 12:42:15 +0000")
    assert hop.from_ip == "198.51.100.14" and hop.external and hop.protocol == "ESMTPSA"


def test_originating_ip_from_receiving_mta(phish):
    r = analyze_headers(phish)
    assert r.originating_ip == "203.0.113.77"
    assert "Received-SPF" in r.originating_ip_source
    assert set(r.external_ips) == {"198.51.100.14", "203.0.113.77"}


def test_pass_but_unaligned_is_detected(phish):
    a = analyze_headers(phish).auth
    assert a.spf == "pass" and a.spf_aligned is False
    assert a.dkim[0]["result"] == "pass" and a.dkim_aligned is False
    assert a.dmarc == "fail" and a.dmarc_computed == "fail" and a.dmarc_policy == "reject"


def test_phish_header_findings(phish):
    c = codes(analyze_headers(phish))
    assert {"DMARC_FAIL", "SPF_UNALIGNED", "DKIM_UNALIGNED", "REPLY_TO_MISMATCH", "BULK_MAILER"} <= c


def test_benign_is_aligned_via_subdomain(benign):
    r = analyze_headers(benign)
    assert r.auth.spf_aligned and r.auth.dkim_aligned and r.auth.dmarc_computed == "pass"
    assert sum(f.points for f in r.findings) == 0


def test_org_domain():
    assert org_domain("login.micros0ft-365-verify.test") == "micros0ft-365-verify.test"
    assert org_domain("mail.example.co.uk") == "example.co.uk"
