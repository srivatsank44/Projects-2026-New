import io
import zipfile

from phishtriage.header_parser import analyze_headers
from phishtriage.ioc_extractor import analyze_attachment, extract_iocs, unwrap_url
from phishtriage.utils import defang, lookalike_brand, refang


def test_extracts_expected_iocs(phish):
    rep = extract_iocs(phish, analyze_headers(phish))
    vals = {(i.type, i.value) for i in rep.iocs}
    assert ("domain", "login.micros0ft-365-verify.test") in vals
    assert ("ip", "198.51.100.23") in vals          # IP-literal URL host
    assert ("ip", "203.0.113.77") in vals           # header originating IP
    assert any(i.type == "hash" for i in rep.iocs)
    allow = [i for i in rep.iocs if i.skip_enrichment]
    assert allow and all("microsoft.com" in i.value for i in allow)


def test_content_findings(phish):
    c = {f.code for f in extract_iocs(phish).findings}
    assert {"DECEPTIVE_LINK_TEXT", "LOOKALIKE_URL_DOMAIN", "DOUBLE_EXTENSION",
            "RISKY_ATTACHMENT", "IP_LITERAL_URL", "RECIPIENT_IN_URL"} <= c


def test_type_mismatch_and_encrypted_zip():
    att, f = analyze_attachment("invoice.pdf", "application/pdf", b"MZ\x90\x00" + b"\x00" * 64)
    assert att.detected_type == "PE executable" and "type-mismatch" in att.flags
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("doc.js", "x")
    data = bytearray(buf.getvalue())
    data[6] |= 0x1  # set encryption flag bit in local header
    cd = data.rfind(b"PK\x01\x02")
    data[cd + 8] |= 0x1  # and in central directory
    att, f = analyze_attachment("scan.zip", "application/zip", bytes(data))
    assert "encrypted-archive" in att.flags and "risky-archive-content" in att.flags


def test_refang_defang_roundtrip():
    assert refang("hxxps://evil[.]test/a") == "https://evil.test/a"
    assert defang("https://evil.test/a.php") == "hxxps://evil[.]test/a.php"


def test_unwrap_safelinks():
    wrapped = "https://nam02.safelinks.protection.outlook.com/?url=https%3A%2F%2Fevil.test%2Fx&data=1"
    assert unwrap_url(wrapped) == "https://evil.test/x"


def test_lookalike():
    assert lookalike_brand("paypa1-secure.test") == "paypal"
    assert lookalike_brand("www.paypal.com") is None
