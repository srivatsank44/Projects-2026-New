# phishtriage — Phishing Email Analysis & Automated Triage

Automates the first 15 minutes of a SOC analyst's phishing investigation: parse a raw `.eml`,
reconstruct the delivery path, independently verify SPF/DKIM/DMARC **alignment**, extract IOCs,
score them against **VirusTotal**, **AbuseIPDB** and **Hybrid Analysis**, and emit an
incident-ready triage report (Markdown + JSON) with MITRE ATT&CK mapping and response actions.

```
$ python -m phishtriage samples/ --offline samples/mock_responses.json
[LOW RISK  ]   0/100  benign_newsletter.eml      ->  reports/PT-20260926-59049247_benign_newsletter.*
[MALICIOUS ] 100/100  m365_credential_phish.eml  ->  reports/PT-20260926-8E37AA6B_m365_credential_phish.*
```

📄 **Sample output:** [`reports/sample_triage_report.md`](reports/sample_triage_report.md)

---

## Pipeline

```mermaid
flowchart LR
    A[Raw .eml] --> B[header_parser<br/>hops · origin IP · SPF/DKIM/DMARC alignment]
    A --> C[ioc_extractor<br/>URLs · domains · IPs · attachment hashes<br/>static content checks]
    B --> C
    C --> D[enrichment<br/>VirusTotal · AbuseIPDB · Hybrid Analysis<br/>rate-limit · cache · offline fixtures]
    B --> E[scoring<br/>weighted verdict · ATT&CK · actions]
    C --> E
    D --> E
    E --> F[report<br/>Markdown + JSON]
```

| Stage | Module | What it does |
|---|---|---|
| Header analysis | `phishtriage/header_parser.py` | Reverses the `Received` chain into chronological hops, separates the TCP-observed IP from the attacker-controlled HELO, picks the originating IP from the most trustworthy source, parses the **topmost** `Authentication-Results`, and recomputes DMARC relaxed alignment. |
| IOC extraction | `phishtriage/ioc_extractor.py` | Pulls URLs from text and HTML (`href`, `src`, `action`), refangs obfuscated IOCs, unwraps SafeLinks/Google redirects, detects deceptive link text and brand look-alikes, hashes attachments and checks magic bytes, double extensions, macros and encrypted archives. |
| Enrichment | `phishtriage/enrichment.py` | Lookup-only API clients with per-provider rate limiting, 429 back-off, on-disk TTL cache and an offline fixture mode that runs the same normalisation code. |
| Scoring | `phishtriage/scoring.py` | Combines header, content and threat-intel evidence into a 0-100 score and verdict; maps findings to ATT&CK; generates response actions. |
| Reporting | `phishtriage/report.py` | Analyst-readable Markdown (defanged IOCs) and a full JSON document for SIEM/SOAR ingestion. |

Detailed design notes: [`docs/PARSING_LOGIC.md`](docs/PARSING_LOGIC.md) · [`docs/API_INTEGRATION.md`](docs/API_INTEGRATION.md) · [`docs/REAL_SAMPLES.md`](docs/REAL_SAMPLES.md)

## Quick start

```bash
git clone <your-repo-url> phishtriage && cd phishtriage
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 1) Demo without API keys (fixture data)
python -m phishtriage samples/ --offline samples/mock_responses.json

# 2) Live enrichment
cp .env.example .env        # add your VT / AbuseIPDB / Hybrid Analysis keys
python -m phishtriage path/to/suspicious.eml --trusted-host yourcompany-com.mail.protection.outlook.com

# 3) Header/content analysis only (no network)
python -m phishtriage path/to/suspicious.eml --no-enrich
```

| Option | Purpose |
|---|---|
| `inputs` | One or more `.eml` files or directories (batch mode) |
| `-o/--out DIR` | Output directory (default `reports/`) |
| `--offline FILE` | Use raw API-shaped fixtures instead of live APIs |
| `--no-enrich` | Skip all threat-intel lookups |
| `--trusted-host SUFFIX` | Your boundary MTA hostname(s); improves originating-IP selection |
| `--cache PATH` | Enrichment cache (default `.cache/enrichment.json`, `''` disables) |
| `--format md,json` | Output formats |

**Exit codes** make it pipeline-friendly: `0` low risk · `1` suspicious · `2` malicious · `3` error.

## Scoring model

```
score = min(100,  min(45, Σ header finding points)      # identity & authentication
               +  min(30, Σ content finding points)     # links, attachments
               +  0.6 × worst IOC reputation score )    # threat intel
MALICIOUS ≥ 70 · SUSPICIOUS 40-69 · LOW RISK < 40
```

The three evidence classes are capped separately so no single class can dominate, and an email
can reach **SUSPICIOUS** on header + content evidence alone. This matters because brand-new
phishing domains often have no reputation history yet. The sample phish scores 69 with
`--no-enrich` and 100 with threat intel. IOC scores use worst-case aggregation across
providers (rationale in `docs/API_INTEGRATION.md`).

## Repository layout

```
phishtriage/
├── phishtriage/            # package
│   ├── header_parser.py    # routing hops, origin IP, SPF/DKIM/DMARC alignment
│   ├── ioc_extractor.py    # URL/IP/domain/attachment extraction + static checks
│   ├── enrichment.py       # VirusTotal, AbuseIPDB, Hybrid Analysis clients
│   ├── scoring.py          # verdict, ATT&CK mapping, response actions
│   ├── report.py           # Markdown/JSON rendering
│   ├── utils.py            # org-domain, defang/refang, look-alike detection
│   └── cli.py
├── samples/                # synthetic safe .eml samples + offline API fixtures
├── reports/                # sample triage report output
├── scripts/build_sample.py # regenerates the synthetic samples
├── docs/                   # parsing logic, API integration, real-sample workflow
└── tests/                  # pytest suite (17 tests, no network)
```

## Testing

```bash
pip install pytest && python -m pytest -q
```

Tests cover hop ordering, HELO-vs-observed IP, originating-IP selection, pass-but-unaligned
detection, subdomain alignment, IOC extraction, attachment magic-byte/encrypted-zip detection,
redirect unwrapping, provider normalisers and full offline end-to-end runs.

## Safety & OPSEC

- **Lookups only.** URLs are never submitted for scanning and attachments are never uploaded. Only
  hashes and indicators are queried, so recipient-personalised links and internal documents don't
  leak to public services.
- Bundled samples are **synthetic**: attacker infrastructure uses the reserved `.test` TLD and RFC 5737
  documentation IP ranges. No live payloads.
- Analyse real samples inside an isolated VM. The tool never renders HTML or opens attachments.
- Reports defang all network indicators (`hxxps://evil[.]test`).

## Roadmap

- Cryptographic DKIM/ARC verification via `dkimpy` (currently uses the receiving gateway's results)
- urlscan.io and WHOIS domain-age enrichment (newly registered domain signal)
- QR-code ("quishing") URL extraction from image attachments
- Direct export to TheHive / Splunk HEC / Microsoft Sentinel
