# Threat-Intel API Integration

## Providers and what each is asked

| Provider | IOC types | Endpoint | Auth header | Free-tier limits* |
|---|---|---|---|---|
| VirusTotal v3 | url, domain, ip, hash | `GET /api/v3/{urls/<id>, domains/<d>, ip_addresses/<ip>, files/<sha256>}` | `x-apikey` | 4 req/min, 500/day |
| AbuseIPDB v2 | ip | `GET /api/v2/check?ipAddress=&maxAgeInDays=90` | `Key` + `Accept: application/json` | 1,000 checks/day |
| Hybrid Analysis v2 | hash | `GET /api/v2/search/hash?hash=` (falls back to `POST` form) | `api-key` + `User-Agent: Falcon Sandbox` | varies by key |

\*Limits change. Check each provider's current documentation and your key's permissions. Some
Hybrid Analysis endpoints require a vetted key.

**VirusTotal URL identifiers** are the unpadded URL-safe base64 of the URL (`vt_url_id()`), which
avoids a submission round-trip. A `404` means "not in dataset" and is reported as *not found*,
never as clean.

## Client architecture

```
BaseClient.lookup(type, value)
 ├─ unsupported type / no key ─────────────► None (provider skipped)
 ├─ offline fixtures? ─► raw = fixtures[provider][value]  (or NOT_FOUND)
 ├─ cache hit? ────────► raw = cached response
 └─ _fetch() ─► RateLimiter.wait() ─► HTTP ─► 429? back-off & retry (x4)
                                            ─► 404? NOT_FOUND
 └─ _normalize(raw) ─► EnrichmentResult{found, score 0-100, verdict, details, link}
```

- **Rate limiting:** a per-client minimum interval (VT defaults to 4/min). `Retry-After` is honoured
  on HTTP 429.
- **Caching:** `.cache/enrichment.json`, keyed `provider:type:value`, 24h TTL. Re-running a batch or
  re-triaging a campaign costs no quota.
- **Fault isolation:** network errors produce `verdict="error"` for that provider only, and the rest of
  the pipeline continues.
- **Offline mode:** fixtures contain **raw API-shaped JSON**, not pre-computed scores, so
  `--offline` and the tests exercise the real `_normalize()` code. Swapping to live mode changes
  only the transport.

## OPSEC: lookups, never submissions

The tool never calls VT `POST /urls`, VT file upload, or HA sandbox submission. Reasons:

1. Phishing URLs often embed the recipient's email address (`?u=j.doe@...`). Submitting them to a
   public service publishes that data and **tips off the attacker** that the lure was analysed.
2. Attachments may contain confidential internal content (for example, a legitimate invoice
   forwarded by mistake). Public sandbox uploads can be downloaded by other subscribers.

A *not found* result is shown explicitly. Deciding whether to detonate is left to the analyst, in a
private sandbox.

## Normalisation → 0-100 score

| Provider | Formula | Rationale |
|---|---|---|
| VirusTotal | `min(100, 12 × malicious + 4 × suspicious)` | Absolute engine counts beat ratios: 6 engines flagging is significant whether 70 or 95 engines ran. 6+ malicious → ≥72 (malicious). |
| AbuseIPDB | `abuseConfidenceScore`, capped at 10 if `isWhitelisted` | The provider's score is already a calibrated confidence value. The whitelist cap avoids flagging shared infrastructure such as major ESPs. |
| Hybrid Analysis | max `threat_score`; floor 85 if any `malicious` verdict, 50 if `suspicious` | Sandbox verdicts reflect observed behaviour and are weighted strongly. |

Verdict bands: `≥70 malicious · 30-69 suspicious · 1-29 low · 0 clean · no data unknown`.

**Per-IOC aggregation = max across providers.** In triage, one credible provider flagging an
indicator is enough to act on. Averaging would let a "not found" from a provider without coverage
dilute a strong positive. False positives are handled downstream by the analyst reviewing the
per-provider columns in the report.

## Adding a provider

```python
class UrlscanClient(BaseClient):
    name, env_var, supports, default_rpm = "urlscan", "URLSCAN_API_KEY", {"url", "domain"}, 60
    def _fetch(self, ioc_type, value):
        return self._request("GET", "https://urlscan.io/api/v1/search/",
                             params={"q": f'domain:"{value}"'}, headers={"API-Key": self.api_key})
    def _normalize(self, ioc_type, value, raw):
        ...  # map to EnrichmentResult
```

Register it in `build_clients()`, add a fixture block to `samples/mock_responses.json`, and add a
normaliser unit test.

## Configuration

`.env` (loaded automatically if `python-dotenv` is installed):

```
VT_API_KEY=...
ABUSEIPDB_API_KEY=...
HYBRID_ANALYSIS_API_KEY=...
```

Providers without a key are skipped with a warning, so the tool works with any subset of keys.
