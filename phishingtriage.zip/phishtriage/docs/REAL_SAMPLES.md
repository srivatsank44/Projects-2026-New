# Working with Real Phishing Samples

The bundled samples are synthetic, so the repo is safe to publish. To show real-world
competence, run the tool against real phishing mail and write up the results.

## Where to get samples

| Source | What you get | Notes |
|---|---|---|
| [phishing_pot](https://github.com/rf-peixoto/phishing_pot) (GitHub) | Thousands of real phishing `.eml` files collected by honeypots | Best bulk source; ideal for batch-mode testing (`python -m phishtriage phishing_pot/email/`). |
| [malware-traffic-analysis.net](https://www.malware-traffic-analysis.net/) | Malspam emails bundled with PCAPs, plus traffic-analysis exercises | Archives are password-protected; the password is given on the site's "about" page. Contains **live malware**. |
| [PhishTool](https://www.phishtool.com/) (Community edition) | Web UI for header/IOC analysis | Useful to **cross-check** your parser's output against an established tool. |
| Your own spam/junk folder | Current, real lures | Gmail: ⋮ → *Download message*. Outlook: *Save as* `.eml` / *View source*. |

## Handling rules

1. Work inside an isolated VM (e.g. REMnux or FLARE-VM) with snapshots. Never on a host that holds credentials.
2. `phishtriage` never renders HTML or opens attachments. Keep it that way: don't double-click `.eml` files.
3. Keep live samples out of your repository (`samples/real/` is git-ignored). GitHub may flag or remove live malware.
4. **Sanitise before publishing a write-up:** replace recipient names/addresses, internal hostnames and
   internal IPs. Keep attacker IOCs, since they are public-interest threat intel, but defang them.

## Suggested write-up workflow

1. Run: `python -m phishtriage samples/real/ -o reports/real/`
2. Compare 2-3 reports against PhishTool's analysis of the same emails. Note where they agree, and
   document any disagreement and which tool was right.
3. Pick one representative case and write a short incident narrative covering timeline, lure theme,
   infrastructure, verdict and containment steps. Commit it as `reports/case_study_<n>.md`.
4. Log parser failures (odd `Received` formats, encodings) as GitHub issues and fix them. A visible
   issue → fix → test history is strong portfolio evidence.
