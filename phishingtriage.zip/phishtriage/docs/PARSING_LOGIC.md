# Parsing Logic

This document explains *why* each parsing decision was made. Most of the value in phishing
header analysis comes from knowing which fields an attacker controls and which were written by
infrastructure you trust.

## 1. Loading the message

`email.parser.BytesParser(policy=policy.default)` is used on the raw bytes. The modern
`policy.default` decodes RFC 2047 encoded-words in display names (e.g.
`=?utf-8?B?TWljcm9zb2Z0?=`), which is where impersonation hides. Headers are whitespace-normalised
(folded continuation lines are joined) before any regex runs.

## 2. Trust model: who wrote which header?

| Header | Written by | Trust |
|---|---|---|
| Topmost `Received`, `Authentication-Results`, `Received-SPF` | **Your** gateway / mailbox servers | High |
| `Received` headers below your boundary MTA | Sender-side servers (possibly the attacker) | Low: can be forged |
| `From`, `Reply-To`, `Subject`, `Message-ID`, `X-Mailer`, `Date` | The sender's client | None: fully attacker-controlled |
| `DKIM-Signature` | Sender, but cryptographically verifiable | Only as good as the verification result |
| `Return-Path` | Your final MTA, copied from `MAIL FROM` | Medium: shows the envelope sender, which the attacker chose |

Every rule below follows from this table.

## 3. Routing hops (`Received` chain)

Each MTA **prepends** a `Received` header, so the list reads newest-first. The parser reverses it
to produce a chronological path (hop 1 = earliest).

For each header:

1. Split on the **last** `;`. Everything after it is the timestamp (RFC 5321 §4.4).
2. `from <HELO> (<detail>)`: the HELO/EHLO string is whatever the connecting client claimed
   (`[192.168.1.23]` in the sample). The parenthetical `detail` is written by the *receiving* server
   and contains the actual TCP peer IP (`unknown [198.51.100.14]`). **The detail IP is preferred;**
   the HELO is only a fallback.
3. `by <host>`: the receiving server. `with <proto>`: ESMTP / ESMTPS / ESMTPSA / etc.
   `ESMTPSA` means the client *authenticated*, which usually indicates a webmail/compromised
   account submission point.
4. Per-hop delay is computed from consecutive timestamps. Negative delays (more than 60s) indicate clock skew
   or a forged hop; delays over an hour indicate queueing or greylisting.

### IP classification

`ipaddress.is_private` is intentionally **not** used, because Python classifies RFC 5737
documentation ranges and other special blocks as private. A narrower internal list is used instead
(RFC 1918, loopback, link-local, CGNAT 100.64/10, ULA). Anything else counts as external.

## 4. Choosing the originating IP

The "originating IP" is the address that connected to **your** perimeter, because that is the first
point in the chain you can trust. Sources are tried in order:

1. `Received-SPF: ... client-ip=`, written by your receiving MTA during the SPF check.
2. `Authentication-Results: ... (sender IP is x.x.x.x)`, the Microsoft 365 format.
3. **Trusted-host walk** (`--trusted-host`): walk the chain newest-to-oldest while `by` belongs to
   your infrastructure. The first external `from` IP is the boundary.
4. Earliest external hop (flagged *unverified*, since it may be forged).
5. `X-Originating-IP` (client-supplied, lowest confidence).

The source used is printed in the report. **All** external hop IPs are still extracted as IOCs.
In the sample, `198.51.100.14` (the attacker's submission client, visible via `ESMTPSA`) is
reported alongside the boundary IP `203.0.113.77`.

## 5. SPF / DKIM / DMARC

### Parsing

Only the **topmost** `Authentication-Results` header is parsed. An attacker can insert a fake
`Authentication-Results: spf=pass dkim=pass dmarc=pass` into their message; it will sit *below*
the one your gateway adds. The value is split on `;` into method segments:

| Segment | Extracted fields |
|---|---|
| `spf=` | result, `smtp.mailfrom` → envelope domain |
| `dkim=` | result, `header.d` (or `header.i`), `header.s` selector (one entry per signature) |
| `dmarc=` | result, `p=` policy, `header.from` |

`Received-SPF` fills SPF if `Authentication-Results` is absent. `DKIM-Signature` `d=`/`s=` values
are used only to fill gaps, and are labelled `unverified` because they are unverified claims.

### Recomputing alignment (the key check)

"SPF pass" and "DKIM pass" say nothing about the domain the user sees. They only prove the
message came from infrastructure authorised by *some* domain. DMARC adds **identifier alignment**:
the authenticated domain must match the visible `From:` domain.

The tool recomputes DMARC relaxed alignment itself:

```
org(x)       = registrable domain of x (Public Suffix List via tldextract, fallback heuristic)
spf_aligned  = spf == pass  AND org(envelope_domain) == org(from_domain)
dkim_aligned = any dkim sig: result == pass AND org(d=) == org(from_domain)
dmarc        = pass if spf_aligned OR dkim_aligned else fail
```

The sample shows the classic pattern: **SPF pass + DKIM pass + DMARC fail**. The attacker
correctly configured SPF and DKIM for their own domain `secure-notify-portal.test` while spoofing
`From: no-reply@microsoft.com`. A dashboard showing two green "pass" checks would mislead an
analyst; the alignment columns make the spoof obvious.

Relaxed mode means `mail.contoso-outdoors.example` aligns with `contoso-outdoors.example`, and the
benign sample tests exactly that. A discrepancy between the gateway's reported DMARC and the
recomputed value is surfaced as `DMARC_DISCREPANCY` for manual review, since it can indicate ARC
overrides or strict-mode policies.

## 6. Identity heuristics

| Finding | Logic |
|---|---|
| `REPLY_TO_MISMATCH` | `org(Reply-To) != org(From)`, so replies go to the attacker (common in BEC). |
| `RETURN_PATH_MISMATCH` | Envelope vs header sender differ. Weak on its own because ESPs do this legitimately, so it is suppressed when `SPF_UNALIGNED` already covers it. |
| `DISPLAY_NAME_ADDRESS` | Display name embeds an email address from another domain: `"ceo@acme.com" <x@evil.test>`. |
| `DISPLAY_NAME_IMPERSONATION` | Display name contains a brand keyword but the From org domain isn't one of that brand's legitimate domains. |
| `LOOKALIKE_SENDER_DOMAIN` | Homoglyph normalisation (`0→o, 1→l, rn→m, vv→w`…) reveals a brand inside a non-brand domain. |
| `MESSAGE_ID_MISMATCH` | Message-ID right-hand side generated by a different org than From. |
| `BULK_MAILER` | Known scripted mailers in `X-Mailer` (PHPMailer, SwiftMailer, etc.). |

## 7. IOC extraction

**Bodies.** Every non-attachment `text/plain` and `text/html` part is decoded with
`get_content()`, which handles quoted-printable/base64 and charsets. Text is **refanged** first
(`hxxp`, `[.]`, `(dot)`, `[:]`), so defanged IOCs pasted from threat reports are still caught.

**URLs.**
- HTML is parsed with `html.parser` (not regex) to collect `href`, `src`, `action`,
  `background` and `data-src`. A regex pass over the full text catches URLs in text nodes and
  plain-text parts.
- Trailing punctuation is stripped; `mailto:`, `cid:`, `tel:` and fragments are ignored.
- Wrappers are unwrapped (Microsoft SafeLinks `url=`, Google `/url?q=`) so the real destination is
  analysed.
- Hostnames become `domain` IOCs; IP-literal hosts become `ip` IOCs with an `IP_LITERAL_URL` finding.
- An allow-list (by org domain) marks noise such as `w3.org` and genuine Microsoft links as
  `skip_enrichment` to save API quota. They still appear in the report.

**Content findings.**
- `DECEPTIVE_LINK_TEXT`: anchor text that *looks like* a URL whose org domain differs from the
  `href` (`https://account.microsoft.com/security` → `login.micros0ft-365-verify.test`).
- `LOOKALIKE_URL_DOMAIN`, `URL_SHORTENER`, `RECIPIENT_IN_URL` (email address pre-filled in the
  query string, typical of personalised credential-harvesting kits), `HTML_FORM_IN_BODY`.

**IPs.** IPv4 regex over bodies, internal ranges excluded, merged with external header IPs. Each IOC
records its source (`header:originating`, `header:received`, `body`).

**Attachments.** Any part with a filename or `Content-Disposition: attachment`:
- MD5/SHA1/SHA256 are computed (SHA256 is used for lookups).
- File type is **sniffed from magic bytes** (PE, ZIP/OOXML, OLE2, PDF, RTF, RAR, 7z, LNK, ISO 9660 at
  offset 0x8001, HTML/SVG) and compared with the extension → `TYPE_MISMATCH`.
- `DOUBLE_EXTENSION` (`.pdf.html`), `RISKY_ATTACHMENT` (html/svg/iso/lnk/one/js/…),
  `MACRO_ATTACHMENT`.
- ZIPs are opened *in memory* without extraction: the encryption flag bit → `ENCRYPTED_ARCHIVE`, and
  risky inner filenames → `RISKY_ARCHIVE_CONTENT`.

## 8. Known limitations

- DKIM is not cryptographically re-verified. The gateway's verdict is trusted (roadmap: `dkimpy`).
- Look-alike detection uses a curated brand list plus homoglyph folding. It does not use
  edit-distance or IDN/punycode confusable tables yet.
- Nested `message/rfc822` attachments are hashed as a whole rather than recursively analysed.
- URLs inside PDFs, Office documents or QR-code images are not extracted.
