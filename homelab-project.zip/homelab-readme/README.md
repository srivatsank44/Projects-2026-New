# Home Lab: Active Directory & SIEM Monitoring Pipeline

**Overview**

Designed and built a fully virtualized enterprise security lab simulating a small corporate network, complete with an Active Directory domain, endpoint monitoring, centralized log management, and adversary simulation — to practice detection engineering and SOC-analyst-style workflows end-to-end.

## Architecture

Built entirely in Oracle VM VirtualBox on an isolated host-only network (`192.168.56.0/24`):

| Component | Role | IP |
|---|---|---|
| Windows Server 2022 | Domain Controller (AD DS, DNS) | 192.168.56.10 |
| Windows 10 Pro | Domain-joined endpoint | 192.168.56.20 |
| Ubuntu Server + Splunk Enterprise | SIEM / log indexer | 192.168.56.30 |
| Kali Linux | Attacker / red team box | 192.168.56.40 |

## What I built

- Stood up an Active Directory forest (`lab.local`) with a Domain Controller, organizational units, and test user accounts
- Joined a Windows 10 endpoint to the domain and deployed **Sysmon** (SwiftOnSecurity config) for detailed process, network, and DNS telemetry
- Installed and configured the **Splunk Universal Forwarder** on the endpoint to ship Windows Security and Sysmon logs to a centralized Splunk Enterprise indexer
- Simulated real-world adversary behavior using **Atomic Red Team**, mapped to MITRE ATT&CK techniques (PowerShell execution, credential access, brute-force authentication)
- Ran network-based attacks from Kali (RDP brute force with Hydra) to generate authentication telemetry
- Built a Splunk dashboard with custom **SPL queries** to visualize key Windows Event IDs: 4624 (successful logon), 4625 (failed logon), Sysmon Event ID 1 (process creation), and RDP connection-manager events
- Configured and validated a **live, scheduled Splunk alert** that detects repeated RDP connection bursts, confirmed with an end-to-end fired trigger

## Skills demonstrated

Active Directory administration, Windows Server/DNS configuration, endpoint telemetry (Sysmon), SIEM deployment and log forwarding (Splunk), SPL query writing and field extraction (`rex`), detection engineering, adversary emulation (MITRE ATT&CK / Atomic Red Team), Splunk alerting and scheduling (cron expressions, throttling, trigger conditions), network troubleshooting (VirtualBox host-only networking, static IP configuration, Windows Firewall rules), and Linux/Windows command-line administration.

---

## Dashboard: Home Lab SOC Dashboard

A Classic Dashboard in Splunk Enterprise with four panels pulling from Windows Security and Sysmon event logs forwarded via the Splunk Universal Forwarder.

### Recent Successful Logins (Event ID 4624)

```spl
index=main source="WinEventLog:Security" EventCode=4624
| table _time, Account_Name, Source_Network_Address, LogonType
| sort -_time
```

![Recent Successful Logins panel](images/dashboard-successful-logins.png)

### Failed Logins by Source IP (Event ID 4625)

```spl
index=main source="WinEventLog:Security" EventCode=4625
| stats count by Source_Network_Address
| sort -count
```

![Failed Logins by Source IP panel](images/dashboard-failed-logins.png)

### Recent Process Creation Events (Sysmon Event ID 1)

Sysmon's raw log uses `Field:` (colon) syntax rather than the `Field=` (equals) syntax Splunk's default key-value extraction expects, so `Image` and `CommandLine` needed explicit `rex` extraction:

```spl
index=main source="WinEventLog:Microsoft-Windows-Sysmon/Operational" EventCode=1
| rex field=_raw "Image:\s+(?<Image>.+)"
| rex field=_raw "CommandLine:\s+(?<CommandLine>.+)"
| table _time, Image, CommandLine
| sort -_time
| head 20
```

![Recent Process Creation Events panel](images/dashboard-sysmon-process-creation.png)

### RDP Connection Activity

```spl
index=main source="WinEventLog:Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational"
| stats count by EventCode
```

![RDP Connection Activity panel](images/dashboard-rdp-connection-activity.png)

---

## Alert: Brute Force Detection - Failed Logins

A scheduled Splunk alert built on the RDP connection-manager channel, since Hydra's RDP module never completes a full NLA handshake and therefore never generates a standard Security-log 4625/LogonType=10 event — the attack is still fully visible via the protocol-level `TerminalServices-RemoteConnectionManager` events instead.

```spl
index=main source="WinEventLog:Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational" EventCode=261
| stats count by ComputerName
| where count >= 3
```

- **Schedule:** Cron (`*/5 * * * *`) — runs every 5 minutes
- **Time range:** Last 15 minutes
- **Trigger condition:** Number of Results > 0, evaluated per-result
- **Throttling:** suppressed for 30 minutes per `ComputerName`, so a sustained attack doesn't spam duplicate alerts
- **Action:** Add to Triggered Alerts, Severity: High

### Confirmed live-fire test

Re-ran a Hydra RDP brute-force attack against the domain-joined endpoint, waited for the next scheduled cron tick, and confirmed the alert fired:

![Alert Trigger History showing a fired alert](images/alert-trigger-history.png)

The scheduler's own search run, showing the exact result that satisfied the trigger condition:

![Scheduler result showing DESKTOP-RC6O7AC.lab.local with count 4](images/alert-fired-scheduler-result.png)

Full detection chain validated: **Hydra RDP attack → TerminalServices-RemoteConnectionManager log → Splunk Universal Forwarder → indexer → scheduled correlation search → triggered alert.**

---

## Notable troubleshooting along the way

A few of the more interesting debugging moments from this build (full details in [BUILD-LOG.md](BUILD-LOG.md)):

- **Sysmon field extraction failure** — diagnosed a `Field:` vs `Field=` syntax mismatch in raw event text and fixed it with explicit `rex` extraction.
- **Attack tool not generating the "expected" event** — Hydra's experimental RDP module never completes NLA, so the obvious Security-log event never appears. Pivoted detection to the RDP-specific event channel instead of assuming the attack failed.
- **Recurring VM clock drift** — the Windows endpoint's clock drifted out of sync with the Splunk server twice across the build (from repeated pause/resume cycles with no persistent NTP source), silently breaking every tight relative-time search until diagnosed by comparing `Get-Date` against the search head's current time.

See the full [BUILD-LOG.md](BUILD-LOG.md) for a complete phase-by-phase record, including every issue hit and how it was resolved.
